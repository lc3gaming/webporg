<?php
    $succeded = true;

    $fullname = $_GET['fullname'] ?? '';
    $email = $_GET['email'] ?? '';
    $colour = $_GET['colour'] ?? '';
    $cardnumber = $_GET['cardnumber'] ?? '';

    $name_err = "";
    if($fullname === ''){
        $name_err = "Full name is required!";
        $succeded = false;
    }else if(count(explode(" ", $fullname)) < 2){
        $name_err = "Full name must be at least 2 words!";
        $succeded = false;
    }

    $mail_err = "";
    if($email === ''){
        $mail_err = "E-mail adress is required!";
        $succeded = false;
    }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $mail_err = "E-mail address is invalid!";
        $succeded = false;
    }

    $colour_err = "";
    if($colour === ''){
        $colour_err = "Colour is required!";
        $succeded = false;
    }else if(!in_array($colour, ["black", "white", "gold", "pink", "blue"])){
        $colour_err = "Colour is invalid!";
        $succeded = false;
    }

    $cardnum_err = "";
    if($cardnumber === ''){
        $cardnum_err = "Card number format is required!";
        $succeded = false;
    } else if(strlen($cardnumber) != 19){
        $cardnum_err = "Card number must be 19 characters long!";
        $succeded = false;
    } else {
        $l = true;
        foreach(explode("-", $cardnumber) as $part){
            $l = $l && (strlen($part) == 4) && filter_var($part, FILTER_VALIDATE_INT);
        }
        $l = $l && (count(explode("-", $cardnumber)) == 4);
        if(!($l)){
            $cardnum_err = "Card number format is invalid!";
            $succeded = false;
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Task 2</title>
</head>
<body>
    <h1>Task 2: You've just won a new phone!</h1>
    <form action="index.php" method="get" novalidate>
        <label for="i1">Your full name:</label> <input type="text" name="fullname" id="i1" value="<?= $fullname ?>"> <?= $name_err ?> <br>
        <label for="i2">Your e-mail address:</label> <input type="text" name="email" id="i2" value=<?= $email ?>> <?= $mail_err ?> <br>
        <label>Choose colour:</label> <?= $colour_err ?> <br>
        <input type="radio" value="black" name="colour" id="i3a" <?= $colour == "black" ? "checked" : "" ?>> <label for="i3a">black</label><br>
        <input type="radio" value="white" name="colour" id="i3b" <?= $colour == "white" ? "checked" : "" ?>> <label for="i3b">white</label><br>
        <input type="radio" value="gold" name="colour" id="i3c" <?= $colour == "gold" ? "checked" : "" ?>> <label for="i3c">gold</label><br>
        <input type="radio" value="pink" name="colour" id="i3d" <?= $colour == "pink" ? "checked" : "" ?>> <label for="i3d">pink</label><br>
        <input type="radio" value="blue" name="colour" id="i3e" <?= $colour == "blue" ? "checked" : "" ?>> <label for="i3e">blue</label><br>
        <label for="i4">Your credit card number:</label>
        <input type="text" name="cardnumber" id="i4" value=<?= $cardnumber ?>> <?= $cardnum_err ?> <br>
        <button type="submit">Click here to get your free phone today!</button>
    </form>

    <div id="success" <?= $succeded ? "" : "hidden" ?>>
        <h2></h2>
		<div id="progress-bar">
			<div id="progress-bar-fill"></div>
		</div>
	</div>

    <h2>Hyperlinks for testing</h2>
    <a href="index.php?fullname=&email=&cardnumber=">fullname=&email=&cardnumber=</a><br>
    <a href="index.php?fullname=Grandma&email=&cardnumber=">fullname=Grandma&email=&cardnumber=</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=&cardnumber=">fullname=Lovely+Grandma&email=&cardnumber=</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=nagyi&cardnumber=">fullname=Lovely+Grandma&email=nagyi&cardnumber=</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=nagyi%40webprog.hu&cardnumber=">fullname=Lovely+Grandma&email=nagyi%40webprog.hu&cardnumber=</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=red&cardnumber=">fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=red&cardnumber=</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=">fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=1234">fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=1234</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=1234.5678.1234.5678">fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=1234.5678.1234.5678</a><br>
    <a href="index.php?fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=1234-5678-1234-5678"><span style="color: green">Correct input: </span>fullname=Lovely+Grandma&email=nagyi%40webprog.hu&colour=pink&cardnumber=1234-5678-1234-5678</a><br>

    <script src="index.js"></script>
    </body>
</html>
