# Task 3: Gift list

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [ ] e.
- [ ] f.
- [ ] g.
- [ ] h.
