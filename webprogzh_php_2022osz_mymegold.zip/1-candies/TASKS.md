# Task 1: Candies

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [x] e.
- [x] f.
