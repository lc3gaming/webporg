<?php

$shop = [
  [ "brand" => "Homemade", "type"  => "Dark chocolate", "price" => 2000 ],
  [ "brand" => "Grandma's", "type"  => "Milk chocolate", "price" => 1500 ],
  [ "brand" => "Worldsweet", "type"  => "Milk chocolate", "price" => 3000 ],
  [ "brand" => "Worldsweet", "type"  => "Dark chocolate", "price" => 4000 ],
  [ "brand" => "Worldsweet", "type"  => "Orange essence", "price" => 4000 ],
  [ "brand" => "Homemade", "type"  => "Milk chocolate", "price" => 1000 ],
  [ "brand" => "Speziale", "type"  => "Apple & Cinnamon", "price" => 1000 ]
];

function findValueInShop($brand, $type){
  global $shop;
  foreach($shop as $elem){
    if($elem["brand"] === $brand && $elem["type"] === $type){
      return $elem["price"];
    }
  }
  return "";
}

function isExtremeInShop($brand, $type){
  global $shop;
  $value = findValueInShop($brand, $type);
  if($value === max(array_column($shop, "price"))){
    return "largest";
  }else if($value === min(array_column($shop, "price"))){
    return "lowest";
  }else{
    return "";
  }
}

function averageOfBrand($brand){
  global $shop;
  $cnt = 0;
  $sum = 0;
  foreach($shop as $elem){
    if($elem["brand"] == $brand){
      $cnt++;
      $sum += $elem["price"];
    }
  }
  return (($cnt == 0) ? "" : round($sum / $cnt));
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="index.css">
  <title>Task 1</title>
</head>
<body>
  <h1>Task 1: Candies</h1>
  <table>
    <tr>
      <th></th>
      <?php $types = array_column($shop, "type"); sort($types)?>
      <?php foreach(array_unique($types) as $type): ?>
        <th> <?= $type ?> </th>
      <?php endforeach ?>
      <th>Average price</th>
    </tr>
    <?php $brands = array_column($shop, "brand"); sort($brands)?>
    <?php foreach(array_unique($brands) as $brand): ?>
        <tr>
          <td> <?= $brand ?> </td>
          <?php foreach(array_unique($types) as $type): ?>
            <td class= <?= isExtremeInShop($brand, $type)?>> <?= findValueInShop($brand, $type)?></td>
          <?php endforeach ?>
          <td><?= averageOfBrand($brand) ?></td>
        </tr>
      <?php endforeach ?>
  </table>
</body>
</html>