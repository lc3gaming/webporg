const controlsDiv = document.querySelector("#controls")
const paintDiv = document.querySelector("#paint")
const widthInput = document.querySelector("#width")
const heightInput = document.querySelector("#height")
const startButton = document.querySelector("#start")
const colorInput = document.querySelector("input[type=color]")
const table = document.querySelector("table")


// Táblázat legenerálása a bement alapján:
function handleStartButtonClick(){
    controlsDiv.style.display = "none" // eltüntetjük a controlsDiv-et
    paintDiv.style.display = "block" // előhozzuk a paintDiv-et
    let w = parseInt(widthInput.value) // widthInput.value stringet ad vissza, ezért parseInt-et kell használni, hogy number legyen
    let h = heightInput.valueAsNumber // Mivel a heightInput type.ja number, van valueAsNumber tulajdonsága, ami numbert ad vissza, tehát ezt nem kell átalakítani
    for (let i = 0; i < h; i++){
        let tr = document.createElement("tr") // létrehozzuk a sort
        for (let j = 0; j < w; j++){
            let td = document.createElement("td") // létrehozunk egy cellát
            tr.appendChild(td) // hozzáfűzzük a cellát a sorhoz
        }
        table.appendChild(tr) // hozzáfűzzük a sort a table-hoz
    }
}

function paintTd(event){
    event.preventDefault() // letiltja az alapműveleteit ( enélkül azt "hiszi" hogy a cellákat akarom huzogatni)
    if (event.type == "click" || event.buttons == 1)  //ne csak ha felette van az egér, hanem kattintásra is működjön, buttons == 1 - le van e nyomva az egér
        this.style.backgroundColor = colorInput.value // a cella hátérszínét beállítjuk az input színére
}

startButton.addEventListener("click", handleStartButtonClick)

delegate(table, "click", "td", paintTd)     // klikkelésre is működjön
delegate(table, "mousemove", "td", paintTd) // ha le van nyomva az egér, és az egeret mozgatjuk, akkor is működjön


function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
}