const outputSpan = document.querySelector("span")
let last = null

function handleClick(event){  
    console.log(event) 

    // ha a lastba még nem került event, ez volt az első kattintás
    if (last === null) {
        outputSpan.innerText = "Várom a második kattintást"

    } else {
        let time = event.timeStamp - last.timeStamp // timeStamp = mikor történt
        let dist  = Math.sqrt(Math.pow((event.screenX - last.screenX), 2) + Math.pow((event.screenY - last.screenY), 2)) // kettő kattintás közötti távolság
        // Kétféle beleyírás a spanba: 
        //outputSpan.innerText = "Elmozdulás: " + dist + " px\nEltelt idő: " + time + "ms"
        outputSpan.innerHTML = "Elmozdulás: " + dist + " px<br>Eltelt idő: " + time + "ms"

    }
    last = event
}

document.addEventListener("click", handleClick)