const table = document.querySelector("table")

/*
//Különbség a this és az event.target között:
function handleMouseOver(event){
    event.target.style.backgroundColor = "blue"  // event.target = a cella van benne, hiába kapjuk meg a delegate-ből a sort
}

*/

function handleMouseOver(){
    this.style.backgroundColor = "blue"  // this = a delegetből kapott targetElement, a sor
}

function handleMouseOut(){
    this.style.backgroundColor = ""
}

delegate(table, "mouseover", "tr", handleMouseOver) 
delegate(table, "mouseout", "tr", handleMouseOut)





function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
}

// parent : szülő
// type : típusa: click, mouseover, mouseout .. stb
// selector : amit keresünk, "-ek között (pl itt a sort)
// handler : a függvény