const ul = document.querySelector("ul")
let firstLi = null

// Delegálás nélkül:
function handleLiClick_(event){ 
    if (!event.target.matches("li"))
        return; // ha nem jó helyen járunk, mert ne li elemen vagyunk, ne csináljon semmit

    if (firstLi !== null){
        let secondLi = event.target;  
        // elég a szöveg értékét megcserélni
        [firstLi.innerText, secondLi.innerText] = [secondLi.innerText, firstLi.innerText];
        firstLi = null;
    } else firstLi = event.target;
}

// Delegálás használatával:
function handleLiClick(){
    if (firstLi !== null){
        let secondLi = this;  //  this = targetElement(delegál függvényből) , event.target = ahova kattintottunk
        [firstLi.innerText, secondLi.innerText] = [secondLi.innerText, firstLi.innerText];
        firstLi = null;
    } else firstLi = this;
}


//ul.addEventListener("click", handleLiClick_)  // delegate nélkül 

delegate(ul, "click", "li", handleLiClick);



// Előadásról:
function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
}
