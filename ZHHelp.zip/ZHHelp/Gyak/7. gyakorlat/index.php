<?php declare(strict_types = 1); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

echo "Hello Világ<br>"; 

function add($a, $b){
    return $a + $b;
}

echo add(2,4)."<br>";

$tomb = [1,2,3,43,0,5];
print_r($tomb);
var_dump($tomb);



?>
<h1> 1. feladat </h1>
<?php

    function fact_c(int $n){
        $r = 1;
        for ($i=2; $i <= $n  ; $i++) { 
            $r *= $i;
        }
        return $r;
    }

    function fact_r(int $n){
        if($n == 0) return 1;
        return $n * fact_r($n -1);
    }

    echo fact_c(5)."<br>";
    echo fact_r(5)."<br>";
?>

<h1> 2. feladat </h1>
<?php
     for ($i=1; $i <= 6; $i++) { 
        echo "<h$i> Hello világ! \$\" </h$i>";
     }

?>
<h1> 3. feladat </h1>
<?php
    $t = [1,2,3,4,5,6,7];

    function paros($x){
        return $x % 2 == 0;
    }
    function negyzet($x){
        return $x * $x;
    }

    $filtered = array_filter($t, 'paros');
    var_dump($filtered)."<br>";

    $negyzetomb = array_map('negyzet',$t);
    var_dump($negyzetomb);

    $filtered2 = array_filter($t, fn($x) => $x % 2 == 0);
    var_dump($filtered2);

    $filtered3 = array_filter($t, function ($x){
        return $x % 2 == 0;
    });
    var_dump($filtered3);

    $c = 0;
    $filtered4 = array_filter($t, function ($x) use ($c){
        return $x % 2 == $c;
    });
    var_dump($filtered4);

    foreach($t as $i){
        echo $i."<br>";
    }
    $atomb = [
        "nev" => "László",
        "kor" => 19,
        "osztondij" => true
    ];
    foreach ($atomb as $k => $v) {
        echo "$k : $v<br>";
    }

    reset($t);
    while ($i = current($t)){
        echo $i."<br>";
        next($t);
    }
?>
<h1> 4. feladat </h1>
<?php 
    $kviz = [
        [
            "kerdes" => "Melyik tömbfüggvény nincs php-ban?",
            "valasz" => [
                "a" => "filter",
                "b" => "map",
                "c" => "some",
                "d" => "sum"
            ],
            "helyes" => "c"
        ],
        [
            "kerdes" => "Melyik http kódból tudjuk, hogy a szerveroldalon van a hiba?",
            "valasz" => [
                1 => "500",
                2 => "400",
                3 => "100"
            ],
            "helyes" => 1
        ] 

        ];
/*
    foreach($kviz as $k => $q){
        echo "<p>{$q['kerdes']}</p>";
        foreach($q['valasz'] as $jel => $szov){
            echo "<input type=\"radio\" name=\"k{$k}\"".($q['helyes'] == $jel ? 'checked' : '').">$jel. $szov <br>";
        }
    }
*/
?>

<?php foreach ($kviz as $k => $q): ?>
    <p><?= $q['kerdes']?></p>
    <?php foreach ($q['valasz'] as $jel => $szov): ?>
        <input type="radio" name="k<?= $k ?>"  <?= $q['helyes'] == $jel ? 'checked' : '' ?> > <?= $jel ?>. <?=  $szov ?><br>
    <?php endforeach ?>
<?php endforeach ?>


</body>
</html>
