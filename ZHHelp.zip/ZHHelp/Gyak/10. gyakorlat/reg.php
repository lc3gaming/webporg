<?php
 $fullname = $_POST['fullname'] ?? '';
 $email = $_POST['email'] ?? '';
 $taj = $_POST['taj'] ?? '';
 $age = $_POST['age'] ?? '';
 $gender = $_POST['gender'] ?? '';
 $accept = $_POST['accept'] ?? false;
 $accept = filter_var($accept, FILTER_VALIDATE_BOOLEAN);
 $date = $_POST['date'] ?? date('Y-m-d');
 $notes = $_POST['notes'] ?? '';

 $errors = [];

 if(count($_POST) > 0){

    if(trim($fullname) === '')
        $errors['fullname'] = "A név kitöltése kötelező";
    else if (count(explode(' ',$fullname)) < 2)
        $errors['fullname'] = "A teljes név legalább két szó legyen!";

    if(trim($email) === '')
        $errors['email'] = "Az email kitöltése kötelező";
    else if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors['email'] = "Addj valid emailcímet";

    if(trim($taj) === '')
        $errors['taj'] = "A taj szám kitöltése kötelező";
    else if(strlen($taj) != 9)
        $errors['taj'] = "A taj szám 9 karakter kell hogy legyen";
    else{
        if( count(array_filter(str_split($taj), fn($char) => $char >= '0' && $char <= '9' )) != 9)
            $errors['taj'] = "A taj számnak számnak kell lennie.";
    }

    if(trim($age) === '')
        $errors['age'] = "A kor  kitöltése kötelező";
    else if(filter_var($age, FILTER_VALIDATE_INT) === false)
        $errors['age'] = "A kor csak szám lehet";
    else{
        $age = intval($age);
        if($age < 1) $errors['age'] = "A kor csak pozitív szám lehet";
    }

    if(trim($gender) === '')
        $errors['gender'] = "A nem  kitöltése kötelező";
    else if($gender !== 'm' && $gender !== 'f')
        $errors['gender'] = "Válassz az itt felsoroltak közűl";

    if(!$accept)
        $errors['accept'] = "A feltételek elfogadása kötelező";


    $errors = array_map(fn($e) => "<span style='color: red'>$e</span>", $errors);
    
 }

  
    if(count($errors) == 0){
        $reg =  json_decode(file_get_contents('data.json'),true);
        if (!isset($reg[$taj])){
            $reg[$taj] = [
                'fullname' => $fullname,
                'taj' => $taj,
                'email' => $email,
                'age' => $age,
                'gender' => $gender,
                'date' => $date,
                'notes' => $notes
            ];

            file_put_contents('data.json', json_encode($reg, JSON_PRETTY_PRINT));


        }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
</head>
    <?php if(count($_POST) > 0 && count($errors) === 0 ):?>
        <span style="color: green;">Sikeres mentés!</span><br>
    <?php endif; ?> 
    <form action="reg.php" method="post">
        Teljes név: <input type="text" name="fullname" value="<?= $fullname ?>"> <?= $errors['fullname'] ?? '' ?> <br>
        E-mail: <input type="text" name="email" value="<?= $email ?>"> <?= $errors['email'] ?? '' ?> <br>
        TAJ szám: <input type="text" name="taj" value="<?= $taj ?>"> <?= $errors['taj'] ?? '' ?><br>
        Életkor: <input type="text" name="age" value="<?= $age ?>">  <?= $errors['age'] ?? '' ?> <br>
        Nem:
            <input type="radio" name="gender" value="m" <?= $gender == "m" ? 'checked' : ''?>>Férfi
            <input type="radio" name="gender" value="f" <?= $gender == "f" ? 'checked' : ''?>>Nő <br>
            <?= $errors['gender'] ?? '' ?> <br>
        <input type="checkbox" name="accept" <?= $accept ? 'checked' : '' ?>> Elfogadom a feltételeket. <?= $errors['accept'] ?? '' ?><br>
        Regisztráció dátuma: <input type="date" name="date" value="<?= $date ?>"><br>
        Megjegyzés: <br><textarea name="notes"><?= $notes ?></textarea><br>
        <button type="submit">Regisztráció</button>
    </form>
    <a href="index.php">Vissza a kezdőlapra</a>
</body>
</html>