// Canvas elem elérése
const canvas = document.querySelector('canvas');
// 2D rajzolási "kontextus" elérése
const context = canvas.getContext('2d');

const gold = {
    x: 10,
    y: 10,
    size: 15
}

const niffler = {
    x: 100,
    y: 100,
    w: 50,
    h: 60,
    speed: 15,
    img: new Image()
}

let counter = 0

// Első betöltésre nem tölti be a képet, ezért ezzel ki lehet egészíteni:
// Így csak a kép betöltése után rajtolja meg a canvast
niffler.img.addEventListener(
    "load",
    () => {
        paintCanvas()
    },
    false,
  );
niffler.img.src = 'niffler.png'
generateGold()


function paintCanvas() {
    context.clearRect(0,0,canvas.width,canvas.height)
    painGold()
    paintNiffler()
    paintText()
    
}

function generateGold() {
    gold.x = Math.floor(Math.random() * (canvas.width - (2 * gold.size)) + (2 * gold.size))
    gold.y = Math.floor(Math.random() * (canvas.height - (2 * gold.size)) + (2 * gold.size))

}
function painGold() {
    context.beginPath()
    context.arc(gold.x,gold.y,gold.size,0, Math.PI * 2)
    context.fillStyle = "gold"
    context.fill()
    context.strokeStyle = 'black'
    context.lineWidth = 1
    context.stroke()
}

function paintText() {
    context.font = "30px Arial"
    context.fillStyle = 'black'
    context.lineWidth = 2
    context.fillText("Érmék száma:" + counter, 10, 50)
}

function paintNiffler() {
    //context.fillStyle = 'gray'
    //context.fillRect(niffler.x, niffler.y, niffler.w, niffler.h)
    context.drawImage(niffler.img,niffler.x, niffler.y, niffler.w, niffler.h)
}

function moveNiffler(event) {
    if (event.key === 'ArrowLeft'){
        niffler.x -= niffler.speed
    }
    if (event.key === 'ArrowRight'){
        niffler.x += niffler.speed
    }
    if (event.key === 'ArrowUp'){
        niffler.y -= niffler.speed
    }
    if (event.key === 'ArrowDown'){
        niffler.y += niffler.speed
    }

    if (foundGold()) {
        counter += 1
        generateGold()
    }

    paintCanvas()
    //console.log(foundGold());
}

function foundGold(){
    return(
        gold.x + gold.size > niffler.x &&
        gold.x - gold.size < niffler.x + niffler.w &&
        gold.y + gold.size > niffler.y &&
        gold.y - gold.size < niffler.y + niffler.h
    )

}

document.addEventListener('keydown', moveNiffler)
