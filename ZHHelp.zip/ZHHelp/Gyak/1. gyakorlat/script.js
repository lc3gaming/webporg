console.log("Hello")

// Elemi feladatok: 3,7,9

/*
3. Készíts egy százalékszámító függvényt! 
Adott a szám, és az is, hogy hány százalékára vagy 
kíváncsi. Az eredményt írd ki!
*/

function percentagecal(num, per){
    return (num * per / 100)
}
console.log(percentagecal(200,50))

/*
Adott két szám. 
Írj függvényt, amely visszaadja 
legnagyobb közös osztójukat
*/
function lnko(a,b){
    if(a < b) [a,b] = [b,a]
    let maradek = a % b
    while(maradek > 0){
        [a,b] = [b,maradek]
        maradek = a % b
    }
    return b
}

console.log(lnko(4,12))
console.log(lnko(4)) 
console.log(lnko(4,12,20))

//Írj függvényt, ami visszaadja egy egész szám faktoriálisát!

function faktorialis(n){
    if(n == 0) return 1
    return n * faktorialis(n-1)
}
console.log(faktorialis(5));

// Programozási tételek: 11, 12, 16, (18)

// 11 Egy számsorozatban keress meg egy negatív számot.

function negativ(n){
    return n < 0
}
tomb = [1,3,-2,-70,122,-9]
console.log(tomb.find(negativ))


//12 Számold meg, hány páros szám van egy számokat tartalmazó tömbben!

function paros(n){
    return n %2 === 0
}
console.log(tomb.filter(paros).length)

// Másik modszerrel

console.log(tomb.filter(e => e % 2 == 0).length)

//16 Döntsd el egy mátrxiról, hogy minden eleme páros-e!

let matrix = [[4,6],[2,22]]
console.log(matrix.flat().every(e => e % 2 === 0))

/*
Készítsd el egy bevásárlólistának megfelelő adatszerkezetet, akkor ha a bevásárlólista
a. csak a termékek nevét tartalmazza;
b. a termékek neve mellett a vásárolandó mennyiséget is tárolja.
Az így elkészült listákat írasd ki a konzolra!
*/

let shoppinglist = [
{ product: "tej", db: 2}, 
{ product: "tojás", db: 3},
{ product: "alma", db: 5}
]

console.log(shoppinglist)

// szebben:
shoppinglist.forEach(item => {
    console.log(`${item.product}: ${item.db} darab`);
  });

// házik: 18, 19, 27 
// teamsen kell elküldni: Hosek Henrietta - v09mtn