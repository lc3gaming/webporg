let numbers = [1, 2, 3, 4, 5]
let string = "Milyen jók ezek a tömbfüggvények!"
let matrix = [ [1, 2, 3, 4, 5], 
            [11, 12, 13, 14, 15],
            [21, 22, 23, 24, 25],
            [31, 32, 33, 34, 35]]

// map()
let doubledNumbers = numbers.map(num => num * 2)
console.log(doubledNumbers) // [2, 4, 6, 8, 10]

// filter()
let evenNumbers = numbers.filter(num => num % 2 == 0)
console.log(evenNumbers) // [2, 4]

// find()
let evenNumber = numbers.find(num => num % 2 == 0)
console.log(evenNumber); // 2

// reduce()
let sum = numbers.reduce((sum, num) => sum + num, 0)
console.log(sum) // 15

// forEach()
numbers.forEach(num => {
  console.log("- " + num)
})

// some()
let hasEven = numbers.some(num => num % 2 == 0)
console.log(hasEven) // true

// every()
let areAllEven = numbers.every(num => num % 2 === 0)
console.log(areAllEven) // false

// indexOf()
let indexOf3 = numbers.indexOf(3)
console.log(indexOf3) // 2

// includes()
let has5 = numbers.includes(5)
console.log(has5) // true

// push()
numbers.push(6)
console.log(numbers) // [1, 2, 3, 4, 5, 6]

// pop()
let removedNumber = numbers.pop()
console.log(removedNumber) // 3
console.log(numbers) // [1, 2, 3, 4, 5]

// shift()
let removedNumber2 = numbers.shift()
console.log(removedNumber2) // 1
console.log(numbers) // [2, 3, 4, 5]

// unshift()
console.log(numbers) // [2, 3, 4, 5]
numbers.unshift(1)
console.log(numbers) // [1, 2, 3, 4, 5]

// split()
let words = string.split(" ")
console.log(words) // ["Milyen", "jók", "ezek", "a", "tömbfüggvények!"]


// splice()
words.splice(0, 1)
console.log(words) // ['jók', 'ezek', 'a', 'tömbfüggvények!']

// join()
let sentence = words.join(" ")
console.log(sentence) // "jók ezek a tömbfüggvények!"

// slice()
let slicedNumbers = numbers.slice(1, 3)
console.log(slicedNumbers) //  [2, 3]

// concat()
let all = numbers.concat(words)
console.log(all) //  [1, 2, 3, 4, 5, 'jók', 'ezek', 'a', 'tömbfüggvények!']

// sort()
words.sort();
console.log(words); // ['a', 'ezek', 'jók', 'tömbfüggvények!']

// reverse()
numbers.reverse()
console.log(numbers) // [5, 4, 3, 2, 1]

// flat()
let flatMatrix = matrix.flat()
console.log(flatMatrix) // [1, 2, 3, 4, 5, 11, 12, 13, 14, 15, 21, 22, 23, 24, 25, 31, 32, 33, 34, 35]
