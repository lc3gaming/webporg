<?php

$workers = [
    [
        "name" => "John Doe",
        "role" => "Fejlesztő",
        "salary" => 50000
    ],
    [
        "name" => "Jane Smith",
        "role" => "Tesztelő",
        "salary" => 45000
    ],
    [
        "name" => "Bob Johnson",
        "role" => "Rendszergazda",
        "salary" => 55000
    ],
    [
        "name" => "Alice Brown",
        "role" => "Grafikus",
        "salary" => 48000
    ],
    [
        "name" => "Charlie White",
        "role" => "Projektvezető",
        "salary" => 60000
    ],
    [
        "name" => "Eva Black",
        "role" => "Ügyfélszolgálati munkatárs",
        "salary" => 42000
    ],
    [
        "name" => "Michael Green",
        "role" => "Adatbázis szakértő",
        "salary" => 58000
    ]
];

$searchedName = "";
if (isset($_GET["searchedName"]) && $_GET["searchedName"] !== "") { 
    $searchedName = $_GET["searchedName"];

    $workers = array_filter($workers, function ($worker) use ($searchedName) {
        return str_contains(strtolower($worker["name"]), strtolower($searchedName));
    });
}

?>
<form action="" method="get">
    <label for="searchedName">Név</label>
    <input type="text" id="" name="searchedName" value="<?= $searchedName ?>">
    <br>
    <button type="submit">Szűrés</button>
</form>
<table>
    <tr>
        <th>NÉV</th>
        <th>BEOSZTÁS</th>
        <th> FIZETÉS</th>
    </tr>
    <?php foreach ($workers as $worker) : ?>
        <tr>  
        <td> <?= $worker["name"] ?> </td>
        <td> <?= $worker["role"] ?> </td>
        <td> <?= $worker["salary"] ?> </td>
        </tr>
    <?php endforeach ?>
</table>