<?php
    $data = [
        [
            "name" => "Kiss Jenő",
            "neptun" => "ABC123",
            "year" => 1996,
            "gender" => "férfi"
        ],
        [
            "name" => "Nagy Klára",
            "neptun" => "XYZ999",
            "year" => 1950,
            "gender" => "nő"
        ],
        [
            "name" => "Erős István",
            "neptun" => "IDDQD8",
            "year" => 1994,
            "gender" => "férfi"
        ]
    ];

?>  