<?php

    if(count($_POST) > 0){
        if(filter_var($_POST["a"], FILTER_VALIDATE_FLOAT)!== false ){
            $a = floatval($_POST["a"]);
            if($a != 0){
                if(filter_var($_POST["b"], FILTER_VALIDATE_FLOAT) !== false){
                    
                    $b = floatval($_POST["b"]);
                    $result = "Eredmény: x = " . (-$b / $a);
                } else $result = "A b nem szám";
            } else $result = "Az a nem lehet 0";
        }else $result = "A a nem szám";
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>ax + b = 0</h1>
    <form action="index.php" method="post">
        a = <input type="text" name="a" value="<?= $_POST["a"] ?? "" ?>"> <br>
        b = <input type="text" name="b" value="<?= $_POST["b"] ?? "" ?>"> <br>
        <button type='submit'>Megold</button>
    </form>
    <?= $result ?? "Küldd el!" ?>

    
</body>
</html>