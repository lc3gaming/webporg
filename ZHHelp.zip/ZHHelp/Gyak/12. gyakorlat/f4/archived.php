<?php

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $data = json_decode(file_get_contents('data.json'), true);
    if (isset($data[$id])) {
        $data[$id]['archived'] = true;
        file_put_contents('data.json', json_encode($data, JSON_PRETTY_PRINT));
        
    } else header('location: index.php');
} else header('location: index.php');
header('location: index.php');

?>