// 1. feladat
// Miyek elemekkel történik?
const greetButton = document.querySelector("#greeting")
const hellospan = document.querySelector("#hello")

//Mi történik?
function handleGreetingButtonClick() {
    hellospan.innerText = "Hello Világ"
}

//Mikor történik?
greetButton.addEventListener("click",handleGreetingButtonClick)

// 13. feladat
const target = Math.floor(Math.random() * 100)
console.log(target);

const guessInput = document.querySelector("input#guess")
const guessButton = document.querySelector("button#guess")
const guessOutput = document.querySelector("span#guess")

function handleGuessButtonClick() {
    let guessed = parseInt(guessInput.value)
    if (guessed === target) guessOutput.innerText = "Kitaláltad"
    else if (guessed > target) guessOutput.innerText = "Kisebbre gondoltam"
    else guessOutput.innerText = "Nagyobbra gondoltam"
}

guessButton.addEventListener("click",handleGuessButtonClick)


// 5. feladat
const urlInput    = document.querySelector("#url")
const showButton  = document.querySelector("#showimage")
const imageOutput = document.querySelector("img")

function handleShowButtonClick(){
    imageOutput.src = urlInput.value // a szöveg ami az inputban vaan
}

showButton.addEventListener("click", handleShowButtonClick)

// 8. feladat

const list = document.querySelector("ul")
const links = document.querySelectorAll("a[href]")

links.forEach(function(link) {
    let e = document.createElement("li")
    e.innerText = link.href
    list.appendChild(e)
});

// 11. feladat

const inputs     = [document.querySelector("#field1"), document.querySelector("#field2"), document.querySelector("#field3")]
const loadButton = document.querySelector("#loadrow")
const table      = document.querySelector("table")

function handleLoadButtonClick(){
    let tr = document.createElement("tr") 
    inputs.forEach(function(field){ 
        let td = document.createElement("td")
        td.innerText = field.value
        field.value = "" 
        tr.appendChild(td)
    })
    table.appendChild(tr)
}

loadButton.addEventListener("click", handleLoadButtonClick)
