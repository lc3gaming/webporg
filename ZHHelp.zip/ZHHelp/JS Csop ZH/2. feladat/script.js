let hueSlider = document.querySelector("#hueSlider")
let grayscaleSlider = document.querySelector("#grayscaleSlider")
let applyFiltersButton = document.querySelector("#applyFilters")
let image = document.querySelector("img")


function handleApplyButtonClicked(){
    image.style.filter = (`grayscale(${grayscaleSlider.value}%) hue-rotate(${hueSlider.value}deg)`)

}


applyFiltersButton.addEventListener("click", handleApplyButtonClicked)