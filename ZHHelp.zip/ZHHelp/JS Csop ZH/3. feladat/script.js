function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
}


let controlsDiv = document.querySelector("#controls")
let size = document.querySelector("#size")
let generateButton = document.querySelector("#generate")
let task1 = document.querySelector("#task1")
let task2 = document.querySelector("#task2")
let task3 = document.querySelector("#task3")
let table = document.querySelector("table")
let chosenNumbers = []


function handleGenerateButtonClicked(){

    controlsDiv.style.display = "none"
    let currSize = parseInt(size.value)
    console.log(currSize)
    createTable(currSize)
}

function createTable(Max){
    for(let i = 1; i <= Max; i++){
        let tr = document.createElement("tr")
        for(let j = 1; j <= Max; j++){
            let td = document.createElement("td")
            td.innerText = i*j
            tr.appendChild(td)
        }
        table.appendChild(tr)
    }
}

function handleNumberClicked(event){
    if(event.target.className != "selected"){
        chosenNumbers.push(parseInt(event.target.innerText))
        event.target.className = "selected"
    }
    else{
        chosenNumbers = chosenNumbers.filter(e => e != parseInt(event.target.innerText))
        event.target.className = ""
    }

    let str1 = ""
    chosenNumbers.sort().forEach(e => str1 +=`, ${e}`)
    str1 = str1.substring(1)
    task1.innerText = str1

    task2.innerText = (chosenNumbers.filter(num => num % 3 == 0)).length

    let digitSum = 0
    for(let i = 0; i < chosenNumbers.length; i++){
        digitSum += Math.floor(parseInt(chosenNumbers[i])/10)
        digitSum += parseInt(chosenNumbers[i])%10
    }
    task3.innerText = digitSum

    console.log(chosenNumbers[0] === 3)

}

generateButton.addEventListener("click", handleGenerateButtonClicked)
delegate(table,"click", "td",handleNumberClicked)
