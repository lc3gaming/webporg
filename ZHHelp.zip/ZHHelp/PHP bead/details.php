<?php
include("storages.php");
//include("pokemonstorage.php");
include("auth.php");

session_start();

$userStorage = new UserStorage();
$pokemonStorage = new PokemonStorage();
$pokeArray = $pokemonStorage->returnArray();
$auth = new Auth($userStorage);

if ($auth->is_authenticated()) {
    $user = $auth->authenticated_user();
}

if(isset($pokeArray)){
    $obj = $pokemonStorage->findOne(['name' => $_GET["name"]]);
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IKémon | Pikachu</title>
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/details.css">
</head>

<body>
    <header>
        <h1><a href="index.php">IKémon</a> > <?= $obj["name"]?></h1>
    </header>
    <div id="content">
        <div id="details">
            <div class="image clr-<?= $obj["type"]?>">
                <img src="<?= $obj["image"]?>" alt="">
            </div>
            <div class="info">
                <div class="description">
                <?= $obj["description"]?></div>
                <span class="card-type"><span class="icon">🏷</span> Type: <?= $obj["type"]?></span>
                <div class="attributes">
                    <div class="card-hp"><span class="icon">❤</span> Health: <?= $obj["hp"]?></div>
                    <div class="card-attack"><span class="icon">⚔</span> Attack: <?= $obj["attack"]?></div>
                    <div class="card-defense"><span class="icon">🛡</span> Defense: <?= $obj["defense"]?></div>
                    <button class="AuthButton" style="float: left; margin-left: 5%; margin-top: 5%">
                        Buy
                    </button>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <p>IKémon | ELTE IK Webprogramozás</p>
    </footer>
</body>
</html>