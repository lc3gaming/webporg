<?php
include("storages.php");
include("auth.php");
session_start();

$userStorage = new Userstorage();
$auth = new Auth($userStorage);

$auth->logout();

header("Location: index.php");
exit();


?>