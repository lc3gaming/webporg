# Háttérszín

## Feladat

Készíts olyan oldalt, amelynek háttérszínét paraméterként lehet megadni.
a) A színkódot URL-ben add meg!
b) Készíts három hivatkozást kék, sárga, piros felirattal, amelyekre kattintva az oldal háttérszíne megfelelően változik!
c) A színkódot űrlap segítségével adjuk meg!

## Lépések

1. Statikus prototípus
2. Dinamikus sablon
3. Adat megadása URL-ben
4. Beolvasás - siker
5. Beolvasás - hiba (regex, alapértelmezett érték)
6. Űrlap: statikus prototípus
7. Űrlap működése GET --> URL
8. Űrlap állapottartása
