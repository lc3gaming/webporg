# Elsőfokú egyenlet megoldó program

## Feladat

Készíts elsőfokú egyenletet (ax+b=0) megoldó oldalt! Űrlapon keresztül lehessen megadni a és b értékét. Hiba esetén az űrlap felett listában jelenjenek meg a hibaüzenetek! A megoldást az űrlap alá írjuk! Gondoskodj az űrlap állapottartásáról!

## Lépések

1. Űrlap megjelenítése (HTML, elsofoku.html)
2. Űrlap feldolgozása, érkező adatok debug kiírása (elsofoku.php)
3. Happy path: beolvas, feldolgoz, kiír
4. Refaktorálás: típusok, üzleti logikai függvény
5. Ellenőrzés, hibakezelés, hibák kiírása
6. Refaktorálás: validate függvény
7. UX: hibák/eredmény megjelenítése az űrlap mellett, űrlap állapottartása
