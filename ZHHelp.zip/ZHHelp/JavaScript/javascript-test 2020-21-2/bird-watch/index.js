const placesInput = document.querySelector('#places')
const speciesInput = document.querySelector('#species')
const button = document.querySelector('#btn-generate')
const tableContainer = document.querySelector('#table-container')
const task1 = document.querySelector('#task-1')
const task2 = document.querySelector('#task-2')
const task3 = document.querySelector('#task-3')
const task4 = document.querySelector('#task-4')
const task5 = document.querySelector('#task-5')
table = document.createElement("table")

let matrix = []

button.addEventListener('click', onGenerate)
function onGenerate(e) {
  const n = placesInput.valueAsNumber
  const m = speciesInput.valueAsNumber

  matrix = generateMatrix(n, m)
  generateTable(matrix)
  console.log(matrix);

  onTask1()
  onTask2()
  onTask3()
}

function generateMatrix(n, m) {
  const matrix = []

  for(let i = 0; i<n; i++) {
    const row = []
    for(let j = 0; j<m; j++) {
      row.push(0)
    }
    matrix.push(row)
  }

  return matrix
}


function generateTable(matrix){

  while(tableContainer.firstChild){
    tableContainer.removeChild(tableContainer.firstChild)
  }

  table = document.createElement("table")

  for(let i = 0; i<matrix.length; i++) {
    let tr = document.createElement("tr")
    for(let j = 0; j<matrix[i].length; j++) {
      let td = document.createElement("td")
      td.innerHTML = matrix[i][j]
      tr.appendChild(td)
    }
    table.appendChild(tr)
  }

  tableContainer.appendChild(table)
}

delegate(tableContainer,"click","td",onTableElementClick)

function onTableElementClick(){
  const tr = this.parentNode
  console.log("Sor: " + (tr.sectionRowIndex + 1))
  console.log("Oszlop: " + (this.cellIndex + 1))
  ++matrix[tr.sectionRowIndex][this.cellIndex]
  
  generateTable(matrix)

  onTask1()
  onTask2()
  onTask3()
}

function xyCoord(td) {
  const tr = td.parentNode
  return {
    x: td.cellIndex,
    y: tr.sectionRowIndex
  }
}

function onTask1(){
  matrix[0].filter((i) => i > 0).length > 0 ? task1.innerHTML = "Yes" : task1.innerHTML = "No"
}

function onTask2(){
  task2.innerHTML = matrix.filter((i) => (i.filter((j) => j>10)).length > 0).length
}

function onTask3(){
  task3.innerHTML = matrix.filter((i) => (i.filter((j) => j > 0)).length == 0).length
  if(task3.innerHTML == "0"){
    task3.innerHTML = "No"
  }
}


function delegate(parent, type, selector, handler) {
  parent.addEventListener(type, function (event) {
      const targetElement = event.target.closest(selector)
      if (this.contains(targetElement)) handler.call(targetElement, event)
  })
}
