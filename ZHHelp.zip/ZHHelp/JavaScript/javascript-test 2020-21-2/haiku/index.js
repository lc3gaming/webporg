const haikuInput = document.querySelector("#haiku-editor")
const charNum = document.querySelector("#number-of-characters")
const rowNum = document.querySelector("#number-of-rows")
const rowVowel = document.querySelector("#vowels-per-row")
const haikuButton = document.querySelector("#btn-copy-haiku")
const haikuList = document.querySelector("#haikus")

function writeToConsole(e){

    //console.log(this.value)
    let str = this.value
    charNum.innerHTML = str.length
    rowNum.innerHTML = Array.from(str).filter((c) => c == "\n").length
    if(str.slice(-1) != '\n'){
        rowNum.innerHTML = parseInt(rowNum.innerHTML) + 1
    }
    //console.log("Első sor magánhangzók: " +Array.from(str.split("\n")[0]).filter((c) => checkVowel(c)).length)
    removeAllChildNodes(rowVowel)
    let firstRow
    let secondRow
    let thirdRow
    let fourthRow = 0
    let tooManyRows = false
    for(let i = 0; i < parseInt(rowNum.innerHTML) ; i++){
        let currRow = str.split('\n')[i]
        let li = document.createElement("li")
        li.innerText = Array.from(currRow).filter((c) => checkVowel(c)).length
        rowVowel.appendChild(li)
        if(i == 0){
            firstRow = parseInt(li.innerText)
        }
        else if(i == 1){
            secondRow = parseInt(li.innerText)
        }
        else if(i == 2){
            thirdRow = parseInt(li.innerText)
        }
        else if(i == 3){
            let fourthRow = thirdRow = parseInt(li.innerText)
        }
    }

    if(firstRow == 5 && secondRow == 7 && thirdRow == 5 && fourthRow == 0 && (parseInt(rowNum.innerHTML) == 3 || parseInt(rowNum.innerHTML) == 2)){
        haikuButton.style.display = "inline"
        haikuInput.closest('p').classList.add("haiku")
    }
    else{
        haikuButton.style.display = "none"
        haikuInput.closest('p').classList.remove("haiku")
    }
}

function checkVowel(c){
    const vowels = "aáeéiíoóöőuúüű"
    if(vowels.includes(c)){
        return true;
    }
    return false
}


function copy(){
    haikuList.innerHTML += `<pre>${haikuInput.value}</pre>`
}

haikuInput.addEventListener("input",writeToConsole)
haikuButton.addEventListener("click",copy)


function removeAllChildNodes(parent) {
    while (parent.firstChild) {
        parent.removeChild(parent.firstChild);
    }
}


function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
}