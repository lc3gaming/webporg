<?php
include("studentstorage.php");
$studentStorage = new StudentStorage();

$students = $studentStorage->findAll();

$colors = [
    'Griffendél' => '#fa9891',
    'Hollóhát' => '#abcef7', 
    'Mardekár' => '#b5f5b6', 
    'Hugrabug' => '#fff99e',
];


$houseCounts = array_count_values(array_column($students, 'house'));
//array(4) { ["Griffendél"]=> int(2) ["Hugrabug"]=> int(1) ["Hollóhát"]=> int(3) ["Mardekár"]=> int(2) }
$mostCommonHouse = array_search(max($houseCounts), $houseCounts);

$longestPatronus = '';
$patronuses = array_column($students, 'patronus');
foreach ($patronuses as $patronus) {
    if (strlen($patronus) > strlen($longestPatronus)) {
        $longestPatronus = $patronus;
    }
}

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Roxforti diákok névsora</title>
    <link rel="stylesheet" href="style.css">
    <style>body {background-color: <?= $colors[$mostCommonHouse] ?>}</style>
</head>
<body>
    <input type="text" name="filterInput">
    <button id="filterButton">Szűrés</button>
    <table>
        <?php foreach($students as $student): ?>
            <tr style="background-color: <?= $colors[$student['house']] ?> ">
                <td> <?= $student['name'] ?> </td>
                <td> <?= $student['house'] ?> </td>
                <td> <?= $student['patronus'] ?> </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <div>
    <p>A legtöbb diákkal rendelkező ház: <?= $mostCommonHouse ?> </p> 
    <p>A leghosszabb nevű patrónus: <?= $longestPatronus ?> </p>
    </div>

    <script src="filter.js"></script>
</body>
</html>
