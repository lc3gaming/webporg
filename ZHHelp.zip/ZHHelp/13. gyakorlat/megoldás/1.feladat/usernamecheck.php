<?php
include('userstorage.php');
include('auth.php');

$userStorage = new UserStorage();
$auth = new Auth($userStorage);

if (count($_GET) > 0 && isset($_GET["username"]) && trim($_GET["username"]) !== "") {
    echo json_encode($auth->user_exists($_GET['username']), JSON_PRETTY_PRINT);
} else {
    echo json_encode(false, JSON_PRETTY_PRINT);
}
?>