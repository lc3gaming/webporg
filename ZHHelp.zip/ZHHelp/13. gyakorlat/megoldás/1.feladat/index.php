<?php
include("workerstorage.php");
include("userstorage.php");
include("auth.php");

session_start();

$userStorage = new UserStorage();
$auth = new Auth($userStorage);

if ($auth->is_authenticated()) {
    $user = $auth->authenticated_user();
} else {
    header("Location: login.php");
}

$workers = [];

$workerStorage = new WorkerStorage();

if (count($_GET) > 0) {
    if (isset($_GET["filter"]) && trim($_GET["filter"]) !== "") {
        $filter = $_GET["filter"];
        $workers = $workerStorage->findMany(function ($worker) use ($filter, $user) {
            return (str_contains($worker['name'], $filter) || str_contains($worker['comment'], $filter)) && $worker["userId"] === $user["id"];
        });
    } else {
        $workers = $workerStorage->findMany(function ($worker) use ($user) {
            return $worker["userId"] === $user["id"];
        });
    }
} else {
    $workers = $workerStorage->findMany(function ($worker) use ($user) {
        return $worker["userId"] === $user["id"];
    });
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <a href="http://webprogramozas.inf.elte.hu/#!/subjects/webprog-pti/gyak/11">11. Gyakorlat / 3. Feladat</a>
    <br>
    <?php if (isset($user)) : ?>
        <h2>Szia <?= $user["username"] ?></h2>
        <form action="logout.php" method="post">
            <button type="submit">Kijelentkezés</button>
        </form>
    <?php else : ?>
        <form action="login.php" method="post">
            <button type="submit">Bejelentkezés</button>
        </form>
        <form action="register.php" method="post">
            <button type="submit">Regisztráció</button>
        </form>
    <?php endif ?>
    <form action="add.php" method="get">
        <button type="submit">Új létrehozása</button>
    </form>
    Filter:
    <input type="text" name="filterInput">
    <button type="submit" id="filterButton">Szűrés</button>
    <table>
        <thead>
            <tr>
                <th>
                    Név
                </th>
                <th>
                    Email
                </th>
                <th>
                    Megjegyzés
                </th>
                <th>

                </th>
                <th>
                    Telefonszám
                </th>
            </tr>
        </thead>
        <tbody id="workersTableBody">
            <?php foreach ($workers as $id => $worker) : ?>
                <tr>
                    <td>
                        <a href="worker.php?id=<?= $id ?>"><?= $worker["name"] ?></a>
                    </td>
                    <td>
                        <?php foreach ($worker["email"] as $email) : ?>
                            <?= $email ?>
                            <?php if ($worker["email"][count($worker["email"]) - 1] !== $email) : ?>
                                <?= "," ?>
                            <?php endif ?>
                        <?php endforeach ?>
                    </td>
                    <td>
                        <textarea name="comment" data-workerid="<?= $id ?>" cols="30" rows="10">
                            <?= $worker["comment"] ?>
                        </textarea>
                    </td>
                    <td>
                        <?= $worker["phoneNumber"] ?>
                    </td>
                    <?php if (isset($user) && $auth->authorize(["admin"])) : ?>
                        <td>
                            <form action="modify.php?id=<?= $id ?>" method="post">
                                <button type="submit">Módosít</button>
                            </form>
                        </td>
                        <td>
                            <form action="remove.php?id=<?= $id ?>" method="post">
                                <button type="submit">Törlés</button>
                            </form>
                        </td>
                    <?php endif ?>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <script src="index.js"></script>
</body>

</html>