<?php
include("userstorage.php");
include("auth.php");

function validate(&$data, &$errors){
    if (isset($_POST["username"]) && trim($_POST["username"]) !== "") {
        $data["username"] = $_POST["username"];
    } else {
        $errors["username"] = "Felhasználó név megadása kötelező!";
    }
    if (isset($_POST["password"]) && trim($_POST["password"]) !== "") {
        $data["password"] = $_POST["password"];
    } else {
        $errors["password"] = "Jelszó megadása kötelező!";
    }

    return count($errors) === 0;
}

$data= [];
$errors = [];
$userStorage = new Userstorage();
$auth = new Auth($userStorage);

if (count($_POST) > 0){
    if(validate($data,$errors)){
        if($auth->user_exists($data['username'])){
            $errors['global'] = "Ez a felhasználónév már foglalt";
        } else {
            $auth->register($data);
            header("Location: login.php");
        }

    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Regisztáció</h1>
    <form action="" method="post">
    <p id="globalError" hidden>Ez a felhasználónév már foglalt</p>
    <label for="username">Felhasználónév:</label>
    <input type="text" name="username" value=<?= $data['username'] ?? ''?>>
    <small><?= $errors["userame"] ?? "" ?></small>
    <br>
    <label for="password">Jelszó:</label>
    <input type="text" name="password" value=<?= $data['password'] ?? ''?>>
    <small><?= $errors["password"] ?? "" ?></small>
    <br>
    <button type="submit">Regisztáció</button>
    </form>
    <script src="registration.js"></script>
</body>
</html>