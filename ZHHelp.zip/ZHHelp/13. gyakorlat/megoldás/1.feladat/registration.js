const usernameInput = document.querySelector("[name=username]");
const globalError = document.querySelector("#globalError")

usernameInput.addEventListener("mouseout", handleUsernameMouseOut)

async function handleUsernameMouseOut() {
    const response = await fetch(`usernamecheck.php?username=${usernameInput.value}`)
    console.log(response);
    const isAlreadyUsed = await response.json() // kiszedjuk az adatokat

    globalError.hidden = !isAlreadyUsed

    console.log(isAlreadyUsed);
}

