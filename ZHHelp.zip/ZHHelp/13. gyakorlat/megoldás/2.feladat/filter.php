<?php
include("studentstorage.php");


if (count($_GET) > 0 && isset($_GET["name"]) && trim($_GET["name"]) !== "") {
    $studentStorage = new StudentStorage();
    $filter = $_GET["name"];
    $filteredStudents = $studentStorage->findMany(function ($student) use($filter) {
        return (str_contains(strtolower($student['name']), strtolower($filter)));
    });
    echo json_encode($filteredStudents, JSON_PRETTY_PRINT);
} else {
    echo json_encode([], JSON_PRETTY_PRINT);
}



?>

