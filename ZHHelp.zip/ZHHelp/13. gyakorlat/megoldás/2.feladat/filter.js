const filterInput = document.querySelector("[name=filterInput]");
const filterButton = document.querySelector("#filterButton");
const table = document.querySelector("table");

colors = {
    'Griffendél':'#fa9891',
    'Hollóhát' :'#abcef7', 
    'Mardekár' : '#b5f5b6', 
    'Hugrabug' : '#fff99e',
};


filterButton.addEventListener("click", async () => {

    const response = await fetch(`filter.php?name=${filterInput.value}`)
    console.log(filterInput.value);
    const students = await response.json()

    console.log(students);

    table.innerHTML = "";
    for (const key in students) {
      table.innerHTML += `

      <tr style="background-color: ${colors[students[key].house]} ">
        <td> ${students[key].name}</td>
        <td> ${students[key].house} </td>
        <td> ${students[key].patronus} </td>
      </tr>
      `;
    }
});