<?php

//print_r(count($_GET));


function validate(&$errors){
    $roomList = ["3bed", "4bed", "6bed-small", "6bed-medium", "6bed-large"];
    if(count($_GET) > 0){
        //name
        if(isset($_GET["name"])){
            if(trim($_GET["name"]) == ""){
                $errors["name"] = "Név megadása kötelező";
            }
            else if(strlen(trim($_GET["name"])) < 8){
                $errors["name"] = "Név túl rövid";
            }
            elseif(strlen(trim($_GET["name"])) > 50){
                $errors["name"] = "Név túl hosszú";
            }
        }
        else{
            $errors["name"] = "Név megadása kötelező";
        }

        //Email
        if(isset($_GET["email"])){
            if(trim($_GET["email"]) == ""){
                $errors["email"] = "Email megadása kötelező";
            }
            else if(filter_var($_GET["email"], FILTER_VALIDATE_EMAIL) == false){
                $errors["email"] = "Hibás email. formátum";
            }
        }
        else{
            $errors["name"] = "Email megadása kötelező";
        }

        //Age
        if(isset($_GET["age"])){
            if(trim($_GET["age"]) == ""){
                $errors["age"] = "Életkor megadása kötelező";
            }
            else if(filter_var($_GET["age"], FILTER_VALIDATE_INT) == false){
                $errors["age"] = "Az életkor csak szám lehet";
            }
            else if($_GET["age"] < 18){
                $errors["age"] = "Túl fiatal";
            }
            else if($_GET["age"] > 99){
                $errors["age"] = "Túl öreg";
            }
        }
        else{
            $errors["age"] = "Életkor megadása kötelező";
        }

        //Room
        if(isset($_GET["room"])){
            if(trim($_GET["room"]) == ""){
                $errors["room"] = "Szoba megadása kötelező";
            }
            else if(!in_array($_GET['room'], $roomList)){
                $errors["room"] = "Nincs ilyen szoba";
            }
        }
        else{
            $errors["room"] = "Szoba megadása kötelező";
        }

        //Travelers
        if(isset($_GET["travelers"])){
            if(trim($_GET["travelers"]) == ""){
                $errors["travelers"] = "Utasok megadása kötelező";
            }

            //print_r(array_filter(explode("\r\n",$_GET['travelers']), "nameLengthCheck"));

            //New line character: "\r\n" (fontos a dupla felső vesső)
            if(count(array_filter(explode("\r\n",$_GET['travelers']), "nameLengthCheck")) > 0){
                $name = array_filter(explode("\r\n",$_GET['travelers']), "nameLengthCheck");
                //echo(implode($name));
                if(strlen(implode($name)) < 8 ){
                    $errors["travelers"] = "Túl rövid utasnév"; 
                }
                else{
                    $errors["travelers"] = "Túl hosszú utasnév"; 
                }
            }
            else if(count(explode("\r\n",$_GET['travelers'])) > $_GET['room'][0]){
                $errors["travelers"] = "Túl sok utas";
            }
        }
        else{
            $errors["travelers"] = "Utasok megadása kötelező";
        }
    }
}

function nameLengthCheck($name){
    if(trim(strlen($name)) > 8 && trim(strlen($name)) < 50){
        return false;
    }
    return true;
}

?>