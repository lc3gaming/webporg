# php-5-validation

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
- [ ] h.