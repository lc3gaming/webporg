const divMap = document.querySelector("#map");
const divInformation = document.querySelector("#information");
const divLines = document.querySelector("#lines");

const formNewLine = document.querySelector("#new-line-form");
const inputNewName = document.querySelector("#new-name");
const inputNewX1 = document.querySelector("#new-x1");
const inputNewY1 = document.querySelector("#new-y1");
const inputNewX2 = document.querySelector("#new-x2");
const inputNewY2 = document.querySelector("#new-y2");
const buttonSelect = document.querySelector("#select");
const buttonSave = document.querySelector("#save");

const inputSelectedName = document.querySelector("#selected-name");
const buttonStart = document.querySelector("#start");
const buttonAutomatic = document.querySelector("#automatic");

let timerID = null
let mousePos = {x: 0, y: 0}
let clickTimes = 0


const lines = [
  {
    name: "Line1",
    stations: [
      {x: 31.344086751431767, y: 73.14579827087277},
      {x: 6.860215301632762, y: 45.750359578024494},
    ],
    activeStation: 0,
    elevatorState: "waiting", // "travelling"
    travelTime: 3,
    waitingTime: 3,
    startTime: -Infinity,
    automatic: false
  },
  {
    name: "Line2",
    stations: [
      {x: 48.9677430123982, y: 72.93667278466782},
      {x: 63.98924868449711, y: 28.602069709218696},
    ],
    activeStation: 0,
    elevatorState: "waiting", // "travelling"
    travelTime: 10,
    waitingTime: 5,
    startTime: -Infinity,
    automatic: false
  },
  {
    name: "Line3",
    stations: [
      {x: 31.935484612538023, y: 72.51842181225793},
      {x: 21.645161829289165, y: 40.31309693669583},
    ],
    activeStation: 0,
    elevatorState: "waiting",
    travelTime: 8,
    waitingTime: 15,
    startTime: -Infinity,
    automatic: false
  },
];


divInformation.children[0].innerHTML = ""
for(let i = 0; i< lines.length; i++){
    divInformation.children[0].innerHTML += lines[i]["name"] + " " + lines[i]["elevatorState"] + "<br>"
}


divLines.removeChild(divLines.children[0])

for(let i = 0; i< lines.length; i++){
  //divInformation.children[0].innerHTML += lines[i]["name"] + " " + lines[i]["elevatorState"] + "<br>"
  let lineDiv = document.createElement("div")
  lineDiv.classList.add("line")
  lineDiv.setAttribute("data-name", lines[i]["name"])

  for(let j = 0; j < (lines[i]["stations"]).length; j++){
    let stationDiv = document.createElement("div")

    stationDiv.classList.add("station")
    stationDiv.style.left = lines[i]["stations"][j].x + "%"
    stationDiv.style.top = lines[i]["stations"][j].y + "%"
    lineDiv.appendChild(stationDiv)
  }

  let elevatorDiv = document.createElement("div")
  elevatorDiv.classList.add("elevator")
  elevatorDiv.setAttribute("style",
   `top: ${lines[i]["stations"][lines[i]["activeStation"]].y}%; left: ${lines[i]["stations"][lines[i]["activeStation"]].x}%; transition-duration: ${lines[i]["travelTime"]}s;`)
  lineDiv.appendChild(elevatorDiv)

  divLines.appendChild(lineDiv)
}


function onStartClicked(){
  //Egy objektum adott oszályű gyereke
  let targetDiv = document.querySelector(`[data-name="${inputSelectedName.value}"]`).querySelector('.elevator')
  let targetElement = lines.find((i) => i["name"] == inputSelectedName.value)
  console.log("Target Element: " + targetElement["name"])
  
  targetElement["activeStation"] = (++targetElement["activeStation"]) % targetElement["stations"].length
  targetElement["elevatorState"] = "travelling"

  targetDiv.style.left = targetElement["stations"][targetElement["activeStation"]].x + "%"
  targetDiv.style.top = targetElement["stations"][targetElement["activeStation"]].y + "%"

  setTimeout(function () {
    targetElement["elevatorState"] = "waiting";  
    targetElement["startTime"] = Date.now()*10e2 + targetElement["waitingTime"];  
  }, targetElement["travelTime"]*1e3);
}


function onAutoClicked(){
  let targetDiv = document.querySelector(`[data-name="${inputSelectedName.value}"]`).querySelector('.elevator')
  let targetElement = lines.find((i) => i["name"] == inputSelectedName.value)

  if(targetElement["automatic"] == false){
    targetElement["automatic"] = true
    timerID = setInterval(onStartClicked , (targetElement["travelTime"] + targetElement["waitingTime"]) * 10e2)
    
  }
  else{
    targetElement["automatic"] = false
    clearInterval(timerID)
  }
}

function onSelectClick(){
  window.addEventListener("mousedown", onMouseClick)
}

function onSaveClick(){
  window.removeEventListener("mousedown", onMouseClick)
  if(clickTimes == 4 + 1){
    let lineDiv = document.createElement("div")
    lineDiv.classList.add("line")
    lineDiv.setAttribute("data-name", inputNewName.value)

    let stationDiv1 = document.createElement("div")
    stationDiv1.classList.add("station")
    stationDiv1.setAttribute("style",
     `left: ${(inputNewX1.value/screen.width) * 100}%; top: ${(inputNewY1.value / screen.availHeight)*100 }%;`)
    lineDiv.appendChild(stationDiv1)

    let stationDiv2 = document.createElement("div")
    stationDiv2.classList.add("station")
    stationDiv2.setAttribute("style",
     `left: ${(inputNewX2.value/screen.width) * 100}%; top: ${(inputNewY2.value / screen.availHeight)*100 }%;`)
    lineDiv.appendChild(stationDiv2)
  
    let elevatorDiv = document.createElement("div")
    elevatorDiv.classList.add("elevator")
    elevatorDiv.setAttribute("style",
     `top: ${stationDiv1.style.top}%; left: ${stationDiv1.style.left}%; transition-duration: 5s;`)
    lineDiv.appendChild(elevatorDiv)
  
    divLines.appendChild(lineDiv)
  }
  
  clickTimes = 0
}

delegate(divLines,"click", "div",onLineClick)
buttonStart.addEventListener("click", onStartClicked)
buttonAutomatic.addEventListener("click", onAutoClicked)
buttonSelect.addEventListener("click", onSelectClick)
buttonSave.addEventListener("click", onSaveClick)
//window.addEventListener("mousedown", onMouseClick)

function onMouseClick(e){
  //console.log("MouseX: " + e.clientX)
  if(clickTimes == 0){
    inputNewX1.value = e.clientX
  } 
  if(clickTimes == 1){
    inputNewY1.value = e.clientY
  }
  if(clickTimes == 2){
    inputNewX2.value = e.clientX
  } 
  if(clickTimes == 3){
    inputNewY2.value = e.clientY
  } 
  clickTimes++
}

function onLineClick(){
  inputSelectedName.value = this.parentNode.getAttribute("data-name")
}


function delegate(parent, type, selector, handler) {
  parent.addEventListener(type, function (event) {
      const targetElement = event.target.closest(selector)
      if (this.contains(targetElement)) handler.call(targetElement, event)
  })
}
