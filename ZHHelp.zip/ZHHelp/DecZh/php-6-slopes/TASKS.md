# php-6-slopes

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
- [ ] e.
- [ ] f.