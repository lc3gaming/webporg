<?php

include("SlopeStorage.php");


$slopeStorage = new SlopeStorage();
$id = $_GET['id'];
$slopeObj = $slopeStorage->findOne(['id' => $id]);

if(isset($slopeObj['dangers'])){
    $learn = 0 < count(array_filter($slopeObj['dangers'], function ($var) {
        return $var == "learners";
    }));
    $ice = 0 < count(array_filter($slopeObj['dangers'], function ($var) {
        return $var == "ice";
    }));
    $fog = 0 < count(array_filter($slopeObj['dangers'], function ($var) {
        return $var == "fog";
    }));
    $acc = 0 < count(array_filter($slopeObj['dangers'], function ($var) {
        return $var == "accident";
    }));
}
else{
    $learn = false;
    $ice = false;
    $fog = false;
    $acc = false;
}

$green = false;
    $red = false;
    $black = false;
    $blue = false;

if(isset($slopeObj['color'])){
    if($slopeObj['color'] == "green"){
        $green = true;
    }
    if($slopeObj['color'] == "blue"){
        $blue = true;
    }
    if($slopeObj['color'] == "red"){
        $red = true;
    }
    if($slopeObj['color'] == "black"){
        $black= true;
    }
}


function Update($slopeStorage){
    if(count($_POST) > 0){
        $slopeStorage -> Update($_POST['id'],[
            "name" => $_POST['name'],
        "length" => $_POST['length'],
        "color" => $_POST['color'],
        "dangers" => $_POST['danger'],
        "id" => $_POST['id']
        ]);
        header("Location: index.php");
    }

}

Update($slopeStorage);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task 6</title>
    <link rel="stylesheet" href="src/index.css">
</head>
<body>
    <h1>Szerkesztés / Edit</h1>
    <form action="edit.php?id=<?= $id ?>" method = "post">
        <input type="hidden" name="id" value="<?= $id ?>">

        <label for="name">Név / Name</label>
        <input type="text" name="name" id="name" value="<?= $slopeObj['name'] ?>">

        <label for="length">Hossz (m) / Length (m)</label>
        <input type="number" name="length" id="length" value="<?= $slopeObj['length'] ?>">

        <label for="color">Szín / Color</label>
        <select name="color" id="color" value=<?= $_POST['color'] ?? "" ?>>
            <option value="green" <?= $green ? "selected" : "" ?>>Zöld / Green</option>
            <option value="blue" <?= $blue ? "selected" : "" ?>>Kék / Blue</option>
            <option value="red" <?= $red ? "selected" : "" ?>>Piros / Red</option>
            <option value="black" <?= $black ? "selected" : "" ?>>Fekete / Black</option>
        </select>

        <label for="danger">Veszélyek / Dangers</label>  
        <div><input type="checkbox" name="danger[]" id="danger-learners" value="learners" <?= $learn ? "checked" : "" ?>><label for="danger-learners">Tanulók / Learners</label></div>
        <div><input type="checkbox" name="danger[]" id="danger-ice" value="ice" <?= $ice ? "checked" : "" ?>><label for="danger-ice">Jég / Ice</label></div>
        <div><input type="checkbox" name="danger[]" id="danger-fog" value="fog" <?= $fog ? "checked" : "" ?>><label for="danger-fog">Köd / Fog</label></div>
        <div><input type="checkbox" name="danger[]" id="danger-accident" value="accident" <?= $acc ? "checked" : "" ?>><label for="danger-accident">Baleset / Accident</label>
        <input type="submit" value="💾">
    </form>
</body>
</html>