<?php
include("storage.php");

class SlopeStorage extends Storage {
    public function __construct() {
      parent::__construct(new JsonIO('slopes.json'));
    }
  }
?>