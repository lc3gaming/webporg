<?php

include("SlopeStorage.php");

$slopeStorage = new SlopeStorage();
$slopeObj = $slopeStorage->findOne(['id' => $_GET['id']]);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task 6</title>
    <link rel="stylesheet" href="src/index.css">
</head>
<body>
    <h1><?= $slopeObj['name'] ?></h1>

    <div>Hossz / Length: <?= $slopeObj['length'] ?> m</div>
    <div>Szín / Color: <?= $slopeObj['color'] ?></div>
    <div>Veszélyek / Dangers:
        <ul>
            <?php foreach($slopeObj['dangers'] as $dng) : ?>
            <li><?= $dng ?></li>
            <?php endforeach ?>
        </ul>
    </div>
</body>
</html>