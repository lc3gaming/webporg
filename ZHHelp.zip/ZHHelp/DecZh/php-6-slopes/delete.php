<?php

include("SlopeStorage.php");

$id = $_GET['id'];
$slopeStorage = new SlopeStorage();

$slopeStorage->delete($id);
header("Location: index.php");
?>