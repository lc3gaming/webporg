<?php

include("SlopeStorage.php");
$slopeStorage = new SlopeStorage();

if(isset($_POST['danger'])){
    $learn = 0 < count(array_filter($_POST['danger'], function ($var) {
        return $var == "learners";
    }));
    $ice = 0 < count(array_filter($_POST['danger'], function ($var) {
        return $var == "ice";
    }));
    $fog = 0 < count(array_filter($_POST['danger'], function ($var) {
        return $var == "fog";
    }));
    $acc = 0 < count(array_filter($_POST['danger'], function ($var) {
        return $var == "accident";
    }));
}
else{
    $learn = false;
    $ice = false;
    $fog = false;
    $acc = false;
}


$green = false;
    $red = false;
    $black = false;
    $blue = false;

if(isset($_POST['color'])){
    if($_POST['color'] == "green"){
        $green = true;
    }
    if($_POST['color'] == "blue"){
        $blue = true;
    }
    if($_POST['color'] == "red"){
        $red = true;
    }
    if($_POST['color'] == "black"){
        $black= true;
    }
}

function Add($slopeStorage) {
    if(count($_POST) > 0){
        
        if(!isset($_POST['danger'])){
            $_POST['danger'] = [];
        }
        

        $slopeObj = $slopeStorage->findOne(['name' => $_POST['name']]);
        print_r($slopeObj);
        if($slopeObj == NULL){
            $slopeStorage -> Add([
                "name" => $_POST['name'],
            "length" => $_POST['length'],
            "color" => $_POST['color'],
            "dangers" => $_POST['danger']
            ]);
        }else{
            $slopeStorage->update($slopeObj['id'], [
            "name" => $_POST['name'],
            "length" => $_POST['length'],
            "color" => $_POST['color'],
            "dangers" => $_POST['danger'],
            "id" => $slopeObj['id']
            ]);
        }
        
    }
}


Add($slopeStorage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task 6</title>
    <link rel="stylesheet" href="src/index.css">
</head>
<body>
    <h1>6. Sípályák / Slopes</h1>
    <form method="post">
        <label for="name">Név / Name</label>
        <input type="text" name="name" id="name" value=<?= $_POST['name'] ?? "" ?>>

        <label for="length">Hossz (m) / Length (m)</label>
        <input type="number" name="length" id="length" value=<?= $_POST['length'] ?? "" ?>>

        <label for="color">Szín / Color</label>
        <select name="color" id="color" value=<?= $_POST['color'] ?? "" ?>>
            <option value="green" <?= $green ? "selected" : "" ?>>Zöld / Green</option>
            <option value="blue" <?= $blue ? "selected" : "" ?>>Kék / Blue</option>
            <option value="red" <?= $red ? "selected" : "" ?>>Piros / Red</option>
            <option value="black" <?= $black ? "selected" : "" ?>>Fekete / Black</option>
        </select>

        <label for="danger">Veszélyek / Dangers</label>  
        <div><input type="checkbox" name="danger[]" id="danger-learners" value="learners" <?= $learn ? "checked" : "" ?>><label for="danger-learners">Tanulók / Learners</label></div>
        <div><input type="checkbox" name="danger[]" id="danger-ice" value="ice" <?= $ice ? "checked" : "" ?>><label for="danger-ice">Jég / Ice</label></div>
        <div><input type="checkbox" name="danger[]" id="danger-fog" value="fog" <?= $fog ? "checked" : "" ?>><label for="danger-fog">Köd / Fog</label></div>
        <div><input type="checkbox" name="danger[]" id="danger-accident" value="accident" <?= $acc ? "checked" : "" ?>><label for="danger-accident">Baleset / Accident</label></div>
        
        <input type="submit" value="+">
    </form>

    <table>
        <thead>
            <tr>
                <th>Név / Name</th>
                <th>Szín / Color</th>
                <th>Törlés / Delete</th>
                <th>Szerkesztés / Edit</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($slopeStorage->findAll() as $slope): ?>
            <tr>
                <td><a href="details.php?id=<?= $slope['id'] ?>"><?= $slope['name'] ?></a></td>
                <td><?= $slope['color'] ?></td>
                <td><a href="delete.php?id=<?= $slope['id'] ?>">🚯</a></td>          
                <td><a href="edit.php?id=<?= $slope['id'] ?>">✏️</a></td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</body>
</html>