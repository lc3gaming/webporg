const task1 = document.querySelector("#task1");
const task2 = document.querySelector("#task2");
const task3 = document.querySelector("#task3");
const task4 = document.querySelector("#task4");
const task5 = document.querySelector("#task5");

// data
console.log(resorts);

// Tasks
// Adj meg egy várost, amely Svájcban vagy Franciaországban van, és a sípályáinak hossza több, mint 200km!
// Find a city in Switzerland or France with more than 200km of ski slopes!
task1.innerHTML = resorts.filter((i) => i["skiSlopeLength"] > 200 && (i["country"] == "France" || i["country"] == "Switzerland"))[0]["city"]

// Mely településeknek van 2000m alatti csúcsa? 
// Which city has a summit below 2000m?
let str = []
task2.innerHTML = resorts.filter((i) => i["highestPoint"] < 2000).map((i) => {
    if(!str.includes(i)){
        str.push(i["city"])
    }
})
task2.innerHTML = str.toString()

let max = -1
let city = ""
for(let i = 0; i< resorts.length; i++){
    if(resorts[i]["skiSlopeLength"] > max){
        max = resorts[i]["skiSlopeLength"]
        city = resorts[i]["city"]
    }
}
task3.innerHTML = city + ", " + max +"km"

resorts.filter((i) => i["skiSlopeLength"] < 40).length > 0 ? task4.innerHTML = "False" : task4.innerHTML = "True"

let countries = []
for(let i = 0; i< resorts.length; i++){
    let index = countries.findIndex((e) => e.country == resorts[i]["country"])
    console.log(index)
    if(index > -1){
        countries[index]["count"]++
    }
    else{
        countries.push({country: resorts[i]["country"], count: 1})
    }
}
console.log(countries)
task5.innerHTML = countries.map(function(i) {
    return "(" + i["country"] + " " +  i["count"] + ")"
})

// Melyik településnek van a leghosszabb sípálya-rendszere? 
// Which city has the longest ski slope system?

// Igaz, hogy mindegyik városban van legalább 40km hosszú pálya?
// Is it true that each city has at least 40km of tracks?

// Add meg, minden országra, hogy hány város képviselteti magát a listában!
// Calculate, for each country, how many cities are represented in the list!

