# js-1-ski-resorts

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
- [ ] e.