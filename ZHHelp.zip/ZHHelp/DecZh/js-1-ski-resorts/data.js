const resorts = [
  {
    city: "Chamonix",
    country: "France",
    lowestPoint: 1035,
    highestPoint: 3842,
    skiSlopeLength: 150
  },
  {
    city: "Zermatt",
    country: "Switzerland",
    lowestPoint: 1620,
    highestPoint: 3883,
    skiSlopeLength: 360
  },
  {
    city: "Kitzbühel",
    country: "Austria",
    lowestPoint: 800,
    highestPoint: 2000,
    skiSlopeLength: 179
  },
  {
    city: "Sierra Nevada",
    country: "Spain",
    lowestPoint: 2100,
    highestPoint: 3300,
    skiSlopeLength: 120
  },
  {
    city: "St. Moritz",
    country: "Switzerland",
    lowestPoint: 1775,
    highestPoint: 3303,
    skiSlopeLength: 350
  },
  {
    city: "Cortina d'Ampezzo",
    country: "Italy",
    lowestPoint: 1224,
    highestPoint: 2932,
    skiSlopeLength: 140
  },
  {
    city: "Verbier",
    country: "Switzerland",
    lowestPoint: 1500,
    highestPoint: 3330,
    skiSlopeLength: 410
  },
  {
    city: "Garmisch-Partenkirchen",
    country: "Germany",
    lowestPoint: 703,
    highestPoint: 2720,
    skiSlopeLength: 124
  },
  {
    city: "Åre",
    country: "Sweden",
    lowestPoint: 380,
    highestPoint: 1274,
    skiSlopeLength: 100
  },
  {
    city: "Jasná",
    country: "Slovakia",
    lowestPoint: 950,
    highestPoint: 2024,
    skiSlopeLength: 49
  },
  {
    city: "Bansko",
    country: "Bulgaria",
    lowestPoint: 936,
    highestPoint: 2560,
    skiSlopeLength: 75
  },
  {
    city: "Avoriaz",
    country: "France",
    lowestPoint: 1100,
    highestPoint: 2466,
    skiSlopeLength: 130
  },
  {
    city: "Bormio",
    country: "Italy",
    lowestPoint: 1225,
    highestPoint: 3012,
    skiSlopeLength: 50
  },
  {
    city: "Kranjska Gora",
    country: "Slovenia",
    lowestPoint: 800,
    highestPoint: 1215,
    skiSlopeLength: 40
  },
  {
    city: "Mürren",
    country: "Switzerland",
    lowestPoint: 1650,
    highestPoint: 2971,
    skiSlopeLength: 54
  },
  {
    city: "Baqueira-Beret",
    country: "Spain",
    lowestPoint: 1500,
    highestPoint: 2510,
    skiSlopeLength: 153
  },
  {
    city: "Engelberg",
    country: "Switzerland",
    lowestPoint: 1030,
    highestPoint: 3020,
    skiSlopeLength: 82
  },
  {
    city: "Zell am See",
    country: "Austria",
    lowestPoint: 757,
    highestPoint: 2000,
    skiSlopeLength: 138
  },
  {
    city: "Bansko",
    country: "Bulgaria",
    lowestPoint: 936,
    highestPoint: 2560,
    skiSlopeLength: 75
  },
  {
    city: "Jahorina",
    country: "Bosnia and Herzegovina",
    lowestPoint: 1300,
    highestPoint: 1916,
    skiSlopeLength: 20
  }
];