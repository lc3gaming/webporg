const inputNumberOfDefenders = document.querySelector("#numberOfDefenders");
const buttonStart = document.querySelector("#buttonStart");
const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");
const canvasWidth = canvas.width;
const canvasHeight = canvas.height;

// Data
let state = 0;   // 0 begin, 1 ingame, 2 lost, 3 won
const ball = {
  x: 30,
  y: canvasHeight / 2 - 8,
  width: 15,
  height: 15,
  vx: 0,
  ax: 0,
}

const origBall = {
  x: 30,
  y: canvasHeight / 2 - 8,
  width: 15,
  height: 15,
  vx: 0,
  ax: 0,
}


const gate = {
  x: canvasWidth - 40,
  y: canvasHeight / 2 -40,
  width: 40,
  height: 80,
}

const origGate = {
  x: canvasWidth - 40,
  y: canvasHeight / 2 -40,
  width: 40,
  height: 80,
}
let defenders = [];

// Time-based animation (from the lecture slide)
let lastFrameTime = performance.now();

function next(currentTime = performance.now()) {
  const dt = (currentTime - lastFrameTime) / 1000; // seconds
  lastFrameTime = currentTime;

  update(dt); // Update current state
  render(); // Rerender the frame
  if(state == 1){
    requestAnimationFrame(next);
  }
}

function update(dt) {
  if(ball.vx < 0){
    ball.vx = 0
  }
  ball.x += ball.vx * dt
  ball.vx += ball.ax * dt

  defenders.forEach((i) => {
    
    if(i.dir <= 0){
      i.dir = -1
    }
    else{
      i.dir = 1
    }

    if(i.y >= canvasHeight - 100){
      i.dir = -1
    }
    if(i.y <= 30){
      i.dir = 1
    }

    i.y += i.vy*i.dir*dt

    if(isCollision(ball, i)){
      console.log("ütközés")
      state = 2
    }
  })

  if(ball.x + ball.width < gate.x + gate.width && ball.x-5 > gate.x){
    state = 3
    console.log("nyertél")
  }
  if(gate.x + gate.width < ball.x){
    state = 2
    console.log("vesztettél")
  }
}

function render() {
  ctx.globalAlpha = 1
  ctx.clearRect(0,0,canvasWidth,canvasHeight)
  defenders.map((i) => ctx.drawImage(defenderImage, i.x, i.y, i.width, i.height))


  ctx.drawImage(ballImage,ball.x, ball.y,ball.width, ball.height)
  ctx.fillStyle = "grey"
  ctx.globalAlpha = 0.5
  ctx.fillRect(gate.x,gate.y,gate.width, gate.height)
}

// Start
const ballImage = new Image();
const defenderImage = new Image();
ballImage.src = "ball.png";
defenderImage.src = "defender.png";


function onStartClick(){
  state = 1
  ball.x = origBall.x
  ball.y = origBall.y
  ball.width = origBall.width
  ball.height = origBall.height
  ball.vx = origBall.vx
  ball.ax = origBall.ax

  defenders = []

  defenders.push({
    x: random(200,canvasWidth -150),
    y: 200,
    width: 40,
    height: 80,
    vy: random(100,300),
    dir: random(-1,1)
  })
  console.log("itt")
  next()
}

function onKeyDown(e){
  if(e.key == "ArrowRight"){
    ball.vx = 300
    ball.ax = -50
  }
  
}


buttonStart.addEventListener("click", onStartClick)
window.addEventListener("keydown", onKeyDown)

// =============== Segédfüggvények =================

function isCollision(box1, box2) {
  return !(
    box2.y + box2.height < box1.y ||
    box1.x + box1.width < box2.x ||
    box1.y + box1.height < box2.y ||
    box2.x + box2.width < box1.x
  );
}

function random(a, b) {
  return Math.floor(Math.random() * (b - a + 1)) + a;
}
