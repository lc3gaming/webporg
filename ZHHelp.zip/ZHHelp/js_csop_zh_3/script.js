// Jó munkát!

function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
}

function drawLottery(n){
    const limits = {5 : 90, 6 : 45, 7 : 35}
    if (!limits.hasOwnProperty(n)) return [];
    const limit = limits[n]
    let draw = []
    while (draw.length < n){
        let rand = Math.floor(Math.random() * limit) + 1
        if (!draw.includes(rand)) draw.push(rand)
    }
    return draw.sort((u, v) => u - v)
}

let controlsDiv = document.querySelector("#controls")
let newButton = document.querySelector("#new")
let table = document.querySelector("table")
let gameSettings = document.querySelector("#game")
let taskDiv = document.querySelector("#tasks")
let drawButton = document.querySelector("#draw")
let task6 = document.querySelector("#task6")
let task7 = document.querySelector("#task7")
let task8 = document.querySelector("#task8")
let task9 = document.querySelector("#task9")
let chosenNumbers = []
let showResults = false

function handleNewButtonClick(){
    controlsDiv.style.display = "none"
    switch(parseInt(gameSettings.value)){
        case 5 : {
            createTable(10,9)
        }
        break
        case 6 : {
            createTable(5,9)
        }
        break
        case 7 : {
            createTable(5,7)
        }
        break
    }
}

function createTable(iMax, jMax){
    for(let i = 0; i < iMax; i++){
        let tr = document.createElement("tr")
        for(let j = 0; j < jMax; j++){
            let td = document.createElement("td")
            if(i > 0){
                td.innerText = `${i}`+`${j+1}`
            }
            else{
                td.innerText = `${j+1}`
            }
            tr.appendChild(td)
        }
        table.appendChild(tr)
    }
}

function handleNumberClicked(event){
    if(event.target.className != "played" && chosenNumbers.length < parseInt(gameSettings.value)){
        chosenNumbers.push(parseInt(event.target.innerText))
        event.target.className = "played"
        if(chosenNumbers.length == parseInt(gameSettings.value)){
            showResults = true
            taskDiv.style.display = "block"
        }
    }
    else{
        chosenNumbers = chosenNumbers.filter(e => e != parseInt(event.target.innerText))
        event.target.className = ""
        if(chosenNumbers.length < parseInt(gameSettings.value)){
            showResults = false
            taskDiv.style.display = "none"
        }
    }
}

function handleDrawButtonClick(){
    let winningNumbers = drawLottery(parseInt(gameSettings.value))
    let str = ""
    winningNumbers.forEach(e => str+=`, ${e}`)
    str = str.substring(1)
    task6.innerText = str

    let matchCounter = 0
    for(let i = 0; i < chosenNumbers.length; i++){
        for(let j = 0; j < winningNumbers.length; j++){
            if(chosenNumbers[i] == winningNumbers[j]){
                matchCounter++
            }
        }
    }
    task7.innerText = matchCounter


    let digitSum = 0
    for(let i = 0; i < winningNumbers.length; i++){
        digitSum += Math.floor(parseInt(winningNumbers[i])/10)
        digitSum += parseInt(winningNumbers[i])%10
    }
    task8.innerText = digitSum

    let isSquare = false
    for(let i = 0; i < winningNumbers.length; i++){
        for(let j = 0; j < winningNumbers.length; j++){
            if(parseInt(winningNumbers[i]) * parseInt(winningNumbers[i]) == parseInt(winningNumbers[j])){
                isSquare = true
            }
        }
    }

    if(isSquare == true){
        task9.innerText = "Van"
    }
    else{
        task9.innerText = "Nincs"
    }

}

newButton.addEventListener("click", handleNewButtonClick)
drawButton.addEventListener("click", handleDrawButtonClick)

delegate(table,"click", "td",handleNumberClicked)
