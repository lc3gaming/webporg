function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
}


function xyCoord(td) {
    const tr = td.parentNode
    return {
      x: td.cellIndex,
      y: tr.sectionRowIndex
    }
}

function removeAllChildNodes(parent) {
    while (parent.firstChild) {
        parent.removeChild(parent.firstChild);
    }
}

window.addEventListener("mousemove", onMouseClick)

function onMouseClick(){
    console.log("MouseX: " + e.clientX)
    console.log("MouseY: " + e.clientY)
}