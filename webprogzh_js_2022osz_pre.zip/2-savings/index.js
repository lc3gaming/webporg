const form = document.querySelector("form");
const divContainer = document.querySelector(".container");

