<?php
$students = [
    ['name' => 'Harry Potter', 'house' => 'Griffendél', 'patronus' => 'Szarvas'],
    ['name' => 'Cedric Diggory', 'house' => 'Hugrabug', 'patronus' => 'Bagoly'],
    ['name' => 'Ron Weasley', 'house' => 'Griffendél', 'patronus' => 'Terrier'],
    ['name' => 'Neville Longbottom', 'house' => 'Griffendél', 'patronus' => 'Menyét'],
    ['name' => 'Luna Lovegood', 'house' => 'Hollóhát', 'patronus' => 'Nyúl'],
    ['name' => 'Sebastian Sallow ', 'house' => 'Mardekár', 'patronus' => 'Mosómedve'],
    ['name' => 'Draco Malfoy', 'house' => 'Mardekár', 'patronus' => 'Kígyó'],
    ['name' => 'Ginny Weasley', 'house' => 'Griffendél', 'patronus' => 'Ló'],
];

$colors = [
    'Griffendél' => '#fa9891',
    'Hollóhát' => '#abcef7', 
    'Mardekár' => '#b5f5b6', 
    'Hugrabug' => '#fff99e',
];

$count = [0,0,0,0];
$houses = ["Griffendél", "Hollóhát", "Mardekár", "Hugrabug"];

$longestLen = 0;
$longestName = "";

foreach($students as $stud){
    if(count(str_split($stud["patronus"])) > $longestLen){
        $longestLen = count(str_split($stud["patronus"]));
        $longestName = $stud["patronus"];
    }
}

foreach($students as $stud){
    if($stud["house"] == "Griffendél"){
        $count[0]++;
    }
    if($stud["house"] == "Hollóhát"){
        $count[1]++;
    }
    if($stud["house"] == "Mardekár"){
        $count[2]++;
    }
    if($stud["house"] == "Hugrabug"){
        $count[3]++;
    }
}

$maxIndex = 0;
$maxValue = 0;


for($i = 0; $i<count($count); $i++){
    if($count[$i] > $maxValue){
        $maxIndex = $i;
        $maxValue = $count[$i];
    }
}   

$max = $houses[$maxIndex];


?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Első feladat</title>
    <link rel="stylesheet" href="style.css">
    <style>body {background-color: white}</style>
</head>
<body style=" background-color: <?= $colors[$houses[$maxIndex]] ?>">

    <table>
        <tr>
            <th>Név</th>
            <th>Ház</th>
            <th>Patrónus</th>
        </tr>
        <?php foreach($students as $stud): ?>
        <tr>
            <td style=" background-color: <?= $colors[$stud["house"]] ?>"><?= $stud["name"] ?></td>
            <td style=" background-color: <?= $colors[$stud["house"]] ?>"><?= $stud["house"] ?></td>
            <td style=" background-color: <?= $colors[$stud["house"]] ?>"><?= $stud["patronus"] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <div>
    <p>A legtöbb diákkal rendelkező ház: <?= $max ?></p> 
    <p>A leghosszabb nevű patrónus: <?= $longestName ?> </p>
    </div>
</body>
</html>
