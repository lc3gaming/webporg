<?php

$name = $_POST["name"] ?? '';
$email = $_POST["email"] ?? '';
$house = $_POST["house"] ?? '';
$errors = [];

if(!empty($_POST)){
    if(trim($name) == ''){
        $errors["name"] = "A név nem lehet üres!";
    }
    else if(count(explode(',', trim($_POST["name"]))) < 2){
        $errors["name"] = "A névnek legalább 2 szóból kell állnia, vesszővel elválasztva!";
    }
    if(trim($email) == ''){
        $errors["email"] = "Az email nem lehet üres!";
    }
    else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errors["email"] = "Hibás email formátum!";
    }
    if(trim($house) == ''){
        $errors["house"] = "Válassz házat!";
    }
    else if($house != "Griffendel" && $house != "Hollohat" && $house != "Mardekar" && $house != "Hugrabug"){
        $errors["house"] = "Érvénytelen ház!";
    }

}

$regText;


if(count($errors) == 0){
    $reg =  json_decode(file_get_contents('data.json'),true);
    if (!isset($reg[$name]) && $name != ""){
        $reg[$name] = [
            'name' => $name,
            'email' => $email,
            "house" => $house
        ];

        $regText = "Sikeres Jelentkezés!";

        file_put_contents('data.json', json_encode($reg, JSON_PRETTY_PRINT));
    }
    else if(count($errors) == 0 && count($_POST) > 0){
        $regText= "Már regisztrálva van!";
    }

}


?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Második feladat</title>
    
</head>
<body>
    <h1>Felvétel a Roxfortba</h1>

    <form action="" method="post">
        <label for="name" >Név:</label>
        <input type="text" name="name" id="name" value="<?= $name ?>"> <?= $errors['name'] ?? '' ?>
        <br>
        <label for="email" >Email:</label>
        <input type="text" name="email" id="email" value="<?= $email ?>"> <?= $errors['email'] ?? '' ?>
        <br>
        <label for="house">Roxforti ház:</label>
        <select name="house" id="house">
            <option value="" selected>-- Válassz --</option>
            <option value="Griffendel" <?= $house == "Griffendel" ? "selected" : '' ?> >Griffendel</option>
            <option value="Hollohat" <?= $house == "Hollohat" ? "selected" : '' ?>>Hollohat</option>
            <option value="Mardekar" <?= $house == "Mardekar" ? "selected" : '' ?>>Mardekar</option>
            <option value="Hugrabug" <?= $house == "Hugrabug" ? "selected" : '' ?>>Hugrabug</option>
        </select> <?= $errors['house'] ?? '' ?> <br>
            <br>
        <button type="submit">Felvétel</button>
    </form>
    <?php if(isset($regText)): ?>
    <span><?= $regText ?></span>
    <?php endif; ?>

</body>
</html>
