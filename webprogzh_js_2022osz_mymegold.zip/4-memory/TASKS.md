# Task 4 - Memory

- [x] a.
- [x] b.
- [x] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
