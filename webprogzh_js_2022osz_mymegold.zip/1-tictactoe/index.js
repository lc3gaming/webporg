const task1 = document.querySelector('#task1');
const task2 = document.querySelector('#task2');
const task3 = document.querySelector('#task3');
const task4 = document.querySelector('#task4');

const game = [
  "XXOO",
  "O OX",
  "OOO ",
];

let data = []
for (const line of game) {
  for (const char of line.split("")) {
    data.push(char)
  }
}

function tasks() {
  task1.innerHTML = game.every((line) => game[0].length == line.length) ? 'true' : 'false'
  task2.innerHTML = !game[0].includes(" ") ? 'true' : 'false' 
  task3.innerHTML = 'X / O = ' + data.filter((e) => e == 'X').length + ' / ' + data.filter((e) => e == 'O').length
  task4.innerHTML = game.indexOf(game.find((line) => line.includes("XXX") || line.includes("OOO")))
}

tasks();