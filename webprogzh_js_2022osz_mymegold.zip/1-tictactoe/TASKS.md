# Task 1 - Tic-tac-toe

- [x] a.
- [x] b.
- [x] c.
- [x] d.
