# Task 2 - Savings

- [x] a.
- [x] b.
- [x] c.
- [x] d.
