const form = document.querySelector("form");
const divContainer = document.querySelector(".container");
const inputAll = document.querySelectorAll("input")

function tasks(){
    
    //a.
    const inputData = Array.from(inputAll)
    let M = 0
    for (const inputElem of inputAll) {
        M = M + parseInt(inputElem.dataset.consumption)
    }
    console.log(M)

    //b.
    let ci = []
    for (const inputElem of inputAll) {
        ci.push((inputElem.value/inputElem.max)*inputElem.dataset.consumption)
    }
    console.log(ci)

    //c.
    for (const inputElem of inputAll) {
        let labelThis = document.querySelector(("label[for="+inputElem.id+"]"))
        labelThis.style.width = (((inputElem.value/inputElem.max)*inputElem.dataset.consumption)/M * 100) + "%"
    }
}
tasks();

//d.
form.addEventListener('input', tasks)
