<?php
include("storage.php");

class GameStorage extends Storage {
    public function __construct() {
      parent::__construct(new JsonIO('data_games.json'));
    }
  }

  class AchievementStorage extends Storage {
    public function __construct() {
      parent::__construct(new JsonIO('data_achievements.json'));
    }
  }
?>