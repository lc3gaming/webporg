# php-6-achievements

- [X] a.(1) Select
- [X] b.(3) Új teljesítmény hozzáadása / Add new achievement
- [ ] c.(3) Szerkesztés / Edit
- [ ] d.(2) Minden teljesítmény listája / List of all achievements
- [ ] e.(2) Játék oldal / Game page
- [ ] f.(3) Törlés / Delete