# php-5-rating

- [X] 0.(0) Hibaüzenetek / Error messages
- [X] a.(2) Kötelező mezők / Required fields
- [X] b.(1) Felhasználónév hossza / Username length
- [X] c.(1) E-mail formátum / E-mail format
- [X] d.(1) Órák: egész szám / Hours: integer
- [X] e.(1) Órák: 0-999 / Hours: 0-999
- [X] f.(2) Értékelés a listában / Rating is in list
- [X] g.(3) Bug, crash
- [X] h.(1) Success