# js-2-download

- [X] a.(1) Szerver és kliens képe / Server and client image
- [X] b.(1) Hálózat vonala / Network line
- [X] c.(1) Csomag képek / Package images
- [X] d.(2) Csomag mozog / Package moves
- [X] e.(1) Csomag megáll / Package stops
- [X] f.(1) Download complete
- [X] g.(2) Veszélyzónák kirajzolása / Draw danger zones
- [X] h.(2) Lassab sebesség veszélyzónában / Slower speed in danger zones
- [X] i.(2) Failed download
- [X] j.(1) Letöltés gomb letiltása / Disable download button