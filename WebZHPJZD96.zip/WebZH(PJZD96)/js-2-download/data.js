const downloadObstacles = {
    dach: [
        { start: 350, width: 20 },
        { start: 480, width: 35 },
        { start: 630, width: 60 }
    ],
    france: [
        { start: 410, width: 95 },
        { start: 700, width: 10 }
    ],
    benelux: [
        { start: 325, width: 100 }
    ],
    visegrad: [
        { start: 320, width: 10 },
        { start: 380, width: 10 },
        { start: 415, width: 10 },
        { start: 490, width: 10 },
        { start: 520, width: 10 },
        { start: 540, width: 10 },
        { start: 590, width: 10 },
        { start: 615, width: 10 },
        { start: 640, width: 10 },
    ],
    nordic: [
        { start: 700, width: 100 }
    ]
}