# php-4-store

- [X] a.(1) Logo
- [X] b.(1) Játék divek / Game divs
- [X] c.(1) Játékok képe / Game images
- [X] d.(1) Képtek címe / Image titles
- [X] e.(1) Sima játék ára / Regular game price
- [X] f.(2) Leárazott játék ára / Discounted game price
- [X] g.(1) Ingyenes játék / Free game
- [X] h.(1) Meg nem jelet játék / Unreleased game
- [X] i.(1) Tizeedesek / Decimals