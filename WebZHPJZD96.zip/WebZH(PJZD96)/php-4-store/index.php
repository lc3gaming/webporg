<?php 

    include("data.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task 4</title>
    <link rel="stylesheet" href="src/index.css">
    <link rel="stylesheet" href="src/task.css">
</head>

<body>
    <header>
        <div>
            <img src="<?= $store_logo ?>" alt="logo">
        </div>
        <h1>4. Store</h1>
    </header>

    <div id="content">
        <!-- Az induló HTML kódot töröld ki és helyette generáld le a data.php fájlból a játékokat -->
        <!-- Delete the starting HTML code and generate the games from the data.php file -->
        <?php foreach($games_associative as $game): ?>
        <div class="game">
            <!-- Ez egy sima játék leárazás nélkül -->
            <!-- This is a normal game without discount -->
            <img src="img/<?= $game['image'] ?>.jpg" title="<?= $game['name'] ?>">
            <div class="info">
                <?php if($game['price'] == 0): ?>
                    <span>Free to play</span>
                <?php endif ?>
                <?php if($game['sale'] > 0): ?>
                    <span class="sale">-<?= $game['sale'] ?>%</span>
                    <span class="original"><?= $game['price'] ?></span>
                    <span class="final"><?= number_format($game['price'] - ($game['price']*$game['sale'])/100, 2) ?></span>
                <?php endif ?>
                <?php if($game['price'] < 0): ?>
                    <span>Add to your whishlist</span>
                <?php endif ?>
                <?php if($game['price'] > 0 && $game['sale'] == 0): ?>
                    <span class="final"><?= $game['price'] ?></span>
                <?php endif ?>
            </div>
        </div>
        <?php endforeach ?>
    </div>
</body>

</html>