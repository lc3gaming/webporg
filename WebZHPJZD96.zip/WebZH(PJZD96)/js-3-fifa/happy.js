//////////////////////////////////////////
// EBBEN A FILEBAN NEM KELL SEMMIT MÓDOSÍTANI
//////////////////////////////////////////


//////////////////////////////////////////
// YOU DON'T NEED TO MODIFY ANYTHING IN THIS FILE
//////////////////////////////////////////










/**
 * Visszaadja adott preferenciájú játékos boldogságát egy adott pozícióban. Nem számít a betűméret.  
 * Returns the happiness of a player with a given preference in a given position. Not case sensitive.
 * ```javascript
 * posHappiness('st', 'cam') // --> 😐
 * posHappiness('gk', 'lw')  // --> 😡
 * posHappiness('rb', 'rb')  // --> 🥰
 * ```
 * @param {String} playerpos A játékos pozíciója. / The position of the player.
 * @param {String} pitchpos  A pozíció, amit vizsgálunk. / The position we are looking at.
 * @returns {String} A boldogság szimbóluma. / The symbol of happiness.
 */
function posHappiness(playerpos, pitchpos){
    playerpos = playerpos.toLowerCase()
    pitchpos = pitchpos.toLowerCase()

    if(playerpos == pitchpos) return '🥰'
    if(playerpos == 'gk' || pitchpos == 'gk') return '😡'

    const emoji = ['🥰', '🙂', '😐', '🙁', '😢']

    /*
        o
        |
    o-o-o-o-o
    |  \|/  |
    \   o   /
     \  |  /
      o-o-o
     / \|/ \
    |   o   |
    o   |   o
     \  |  /
      o-o-o

        o
    */
    const positionGraph = {
        st: ['cf'],

        lw: ['lf', 'lm'],
        lf: ['cf', 'lw', 'cam'],
        cf: ['st', 'lf', 'rf', 'cam'],
        rf: ['cf', 'rw', 'cam'],
        rw: ['rf', 'rm'],

        cam: ['cf', 'lf', 'rf', 'cm'],

        lm: ['lw', 'cdm', 'lwb', 'cm'],
        cm: ['cam', 'lm', 'rm', 'cdm'],
        rm: ['rw', 'cm', 'rwb', 'cdm'],

        cdm: ['cm', 'lm', 'rm', 'cb'],

        lwb: ['lm', 'lb'],
        lb: ['lwb', 'cb'],
        cb: ['lb', 'cb', 'rb'],
        rb: ['rwb', 'cb'],
        rwb: ['rm', 'rb']
    }

    function distanceBetweenNodes(startNode, endNode) {
        if(startNode == endNode) return 0

        const queue = [startNode]
        const visited = new Set([startNode])
        const distances = { [startNode]: 0 }

        while (queue.length > 0) {
            const currentNode = queue.shift()

            for (const neighbor of positionGraph[currentNode]) {
                if (!visited.has(neighbor)) {
                    visited.add(neighbor)
                    queue.push(neighbor)
                    distances[neighbor] = distances[currentNode] + 1

                    if (neighbor === endNode) {
                        return distances[endNode]
                    }
                }
            }
        }
        return -1;
    }

    const distance = distanceBetweenNodes(playerpos, pitchpos)
    if(distance == -1 || distance >= emoji.length) return '😡'
    return emoji[distance]
}