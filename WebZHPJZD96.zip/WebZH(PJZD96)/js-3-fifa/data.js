function getPlayerByNumber(number) {
    return players.find(player => player.number == number);
}

const players = [
    {
        name: 'Giorgio Batorini',
        number: 1,
        pos: 'gk',
        src: 'batorini.jpg'
    },
    {
        name: 'Lorenzo Valentino',
        number: 2,
        pos: 'lm',
        src: 'valentino.jpg'
    },
    {
        name: 'Viktor Grünwald',
        number: 7,
        pos: 'rw',
        src: 'grunwald.jpg'
    },
    {
        name: 'Dénes Sváb',
        number: 14,
        pos: 'cdm',
        src: 'svab.jpg'
    },
    {
        name: 'Mirata Layka',
        number: 16,
        pos: 'cam',
        src: 'layka.jpg'
    },
    {
        name: 'Aaron Doggo',
        number: 19,
        pos: 'rb',
        src: 'doggo.jpg'
    },
    {
        name: 'Dalme D\'Ace',
        number: 20,
        pos: 'cf',
        src: 'dace.jpg'
    },
    {
        name: 'Pietro Kovincky',
        number: 26,
        pos: 'rm',
        src: 'kovincky.jpg'
    },
    {
        name: 'Wolf Benke',
        number: 30,
        pos: 'st',
        src: 'benke.jpg'
    },
    {
        name: 'Lazovic Nikolic',
        number: 34,
        pos: 'cm',
        src: 'nikolic.jpg'
    },
    {
        name: 'Valentine Cher',
        number: 44,
        pos: 'lw',
        src: 'cher.jpg'
    },
    {
        name: 'Bendegúz Kiss',
        number: 50,
        pos: 'gk',
        src: 'kiss.jpg'
    },
    {
        name: 'Laori Rataka',
        number: 63,
        pos: 'lb',
        src: 'rataka.jpg'
    },
    {
        name: 'Christopher Carlaise',
        number: 69,
        pos: 'st',
        src: 'carlaise.jpg'
    },
    {
        name: 'Räscho Held',
        number: 99,
        pos: 'gk',
        src: 'held.jpg'
    },
]