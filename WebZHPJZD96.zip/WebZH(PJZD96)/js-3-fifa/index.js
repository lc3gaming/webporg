const playerList = document.querySelector('#playerlist')
const plannedPosition = document.querySelector('#planned-position')
const playerName = document.querySelector('#personalinfo #name')
const playerEmoji = document.querySelector('#personalinfo #emoji')
const playerImg = document.querySelector('#personalinfo img')

let player = getPlayerByNumber(50)
playerName.innerHTML = player.name
playerImg.src = "img/" + player.src
playerEmoji.innerHTML = posHappiness(player.pos,plannedPosition.value)


// players = [{name: 'Name', number: 00, pos: 'ps', src: 'something.jpg'} ...]
console.log(players)
console.log(
    posHappiness('gk', 'gk'),
    posHappiness('gk', 'st'),
    posHappiness('st', 'st'),
    posHappiness('st', 'lw')
)


while(playerList.firstChild){
    playerList.removeChild(playerList.firstChild)
}

for(let i = 1; i < players.length; i++){
    let playerSpan = document.createElement("span")
    playerSpan.classList.add("player")
    playerSpan.classList.add("pos-" + players[i].pos)
    playerSpan.setAttribute("data-number", players[i].number)
    playerSpan.innerHTML = players[i].name + " (" + players[i].number + ")"
    playerList.appendChild(playerSpan)
}


function onPlayerClick(){
    player = getPlayerByNumber(this.getAttribute("data-number"))
    playerName.innerHTML = player.name
    playerImg.src = "img/" + player.src
    playerEmoji.innerHTML = posHappiness(player.pos,plannedPosition.value)
}

function onNewPos(){
    playerEmoji.innerHTML = posHappiness(player.pos,plannedPosition.value)
}

delegate(playerList,"click", "span",onPlayerClick)
plannedPosition.addEventListener("click", onNewPos)

function delegate(parent, type, selector, handler) {
    parent.addEventListener(type, function (event) {
        const targetElement = event.target.closest(selector)
        if (this.contains(targetElement)) handler.call(targetElement, event)
    })
  }
  