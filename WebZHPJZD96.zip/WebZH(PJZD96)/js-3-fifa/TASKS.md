# js-3-fifa

- [X] a.(2) Játékos elemek / Player elements
- [X] b.(1) Játékos pozíció / Player position
- [X] c.(1) Játékos száma / Player number
- [X] d.(1) Játékos neve / Player name
- [X] e.(1) Játékos portréja / Player portrait
- [X] f.(2) Játékos boldogsága / Player happiness
- [X] g.(2) Delegálás / Delegation
- [X] h.(2) Boldogság frissítése / Update happiness
