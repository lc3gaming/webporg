const task1 = document.querySelector("#task1")
const task2 = document.querySelector("#task2")
const task3 = document.querySelector("#task3")
const task4 = document.querySelector("#task4")
const task5 = document.querySelector("#task5")

console.log(games)


task1.innerHTML = games.filter((i) => i["price"] > 60).length == 0
task2.innerHTML = games.filter((i) => i["peak"] > 1000000)[0]['name']

let min = games[0]['peak'];
let minName = games[0]['name']
for(let i = 1; i < games.length; i++){
    if(games[i]['peak'] < min){
        min = games[i]['peak']
        minName = games[i]['name']
    }
}

task3.innerHTML = minName


task4.innerHTML = games.filter((i) => i["price"] == 0.0).map((i) => {
    return " " + i['name']
})


let price = 0
games.filter((i) => {
    for(let j = 0; j< i['genre'].length; j++){
        if(i['genre'][j] == "strategy"){
            return true
        }
    }
    return false
}).map((i) => {
    price+=i['price']
})

task5.innerHTML = price.toFixed(2)