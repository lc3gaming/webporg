# js-1-statistics

- [X] a.(1) 60-nál olcsóbb / Cheaper than 60
- [X] b.(2) 1.000.000 játékos / 1,000,000 players
- [X] c.(2) Legkevesebb / Fewest
- [X] d.(2) Ingyenes / Free
- [X] e.(2) Stratégia össz ár / Strategy total price
- [X] f.(1) Két tizedes / Two decimals